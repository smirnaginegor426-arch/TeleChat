import { i as __toESM } from "../_runtime.mjs";
import { L as require_react, v as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as Lock, B as Camera, C as Paperclip, D as MessageCircle, E as Mic, F as Copy, H as BellOff, I as CircleHelp, L as ChevronRight, M as ImagePlus, N as Forward, O as Mail, P as Ellipsis, R as Check, S as Pause, T as Moon, U as ArrowLeft, V as Bell, W as Archive, _ as Plus, a as UserPlus, b as Phone, c as Sun, d as Smartphone, f as Shield, g as Search, h as Send, i as UserRound, j as Info, k as LogOut, l as Square, m as Settings, n as Volume2, p as ShieldBan, r as Users, s as Trash2, t as X, u as Sparkles, v as Play, w as Palette, x as Pencil, y as Pin, z as CheckCheck } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C8zK5srG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function TelechatMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("size-8", className),
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "10",
				fill: "var(--color-accent)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8.5 11.2c0-1.2 1-2.2 2.2-2.2h10.6c1.2 0 2.2 1 2.2 2.2v7.1c0 1.2-1 2.2-2.2 2.2h-6.1L9.8 23.6c-.6.4-1.3-.1-1.3-.8v-11.6Z",
				fill: "var(--color-accent-fg)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "13.1",
				cy: "14.6",
				r: "1.15",
				fill: "var(--color-accent)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16.5",
				cy: "14.6",
				r: "1.15",
				fill: "var(--color-accent)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "19.9",
				cy: "14.6",
				r: "1.15",
				fill: "var(--color-accent)"
			})
		]
	});
}
var APP_NAME = "TeleChat";
var STORAGE_KEY = "telechat.v1";
var MAX_IMAGE_EDGE = 1280;
var REACTIONS = [
	{
		id: "heart",
		label: "Нравится"
	},
	{
		id: "like",
		label: "Ок"
	},
	{
		id: "fire",
		label: "Огонь"
	},
	{
		id: "laugh",
		label: "Смешно"
	},
	{
		id: "wow",
		label: "Вау"
	},
	{
		id: "sad",
		label: "Жаль"
	}
];
var ANIMALS = [
	{
		id: "fox",
		label: "Лиса",
		hue: 22
	},
	{
		id: "cat",
		label: "Кот",
		hue: 28
	},
	{
		id: "owl",
		label: "Сова",
		hue: 210
	},
	{
		id: "bear",
		label: "Медведь",
		hue: 28
	},
	{
		id: "panda",
		label: "Панда",
		hue: 0
	},
	{
		id: "wolf",
		label: "Волк",
		hue: 220
	},
	{
		id: "rabbit",
		label: "Кролик",
		hue: 340
	},
	{
		id: "whale",
		label: "Кит",
		hue: 205
	},
	{
		id: "bird",
		label: "Птица",
		hue: 48
	},
	{
		id: "tiger",
		label: "Тигр",
		hue: 30
	},
	{
		id: "frog",
		label: "Лягушка",
		hue: 120
	},
	{
		id: "dog",
		label: "Пёс",
		hue: 32
	},
	{
		id: "deer",
		label: "Олень",
		hue: 18
	},
	{
		id: "penguin",
		label: "Пингвин",
		hue: 210
	},
	{
		id: "koala",
		label: "Коала",
		hue: 40
	},
	{
		id: "otter",
		label: "Выдра",
		hue: 24
	}
];
var COMING_SOON = {
	calls: {
		title: "Звонки",
		body: "Голосовые и видеозвонки появятся в следующем обновлении TeleChat."
	},
	stories: {
		title: "Истории",
		body: "Короткие истории на 24 часа уже в разработке — следите за обновлениями."
	},
	channels: {
		title: "Каналы",
		body: "Публичные каналы для трансляций и новостей появятся позже."
	},
	secret: {
		title: "Секретные чаты",
		body: "Сквозное шифрование с таймером самоуничтожения пока в разработке."
	},
	payments: {
		title: "Платежи",
		body: "Переводы и чаевые внутри TeleChat ещё не подключены."
	},
	bots: {
		title: "Боты",
		body: "Каталог ботов и мини-приложений появится в одной из следующих версий."
	},
	stickers: {
		title: "Стикеры",
		body: "Наборы стикеров и анимированные реакции скоро будут доступны."
	},
	export: {
		title: "Экспорт чата",
		body: "Выгрузка истории в файл появится вместе с облачным архивом."
	},
	folders: {
		title: "Папки чатов",
		body: "Свои папки и фильтры можно будет настроить в следующем релизе."
	},
	"live-location": {
		title: "Геолокация",
		body: "Отправка точки на карте и живая геолокация пока недоступны."
	},
	polls: {
		title: "Опросы",
		body: "Опросы в группах появятся вместе с викторинами."
	},
	translation: {
		title: "Перевод",
		body: "Автоперевод сообщений ещё в разработке."
	}
};
var WALLPAPERS = [
	{
		id: "ink",
		label: "Чернила"
	},
	{
		id: "dusk",
		label: "Сумерки"
	},
	{
		id: "mist",
		label: "Туман"
	},
	{
		id: "tide",
		label: "Прилив"
	},
	{
		id: "paper",
		label: "Бумага"
	}
];
var t = {
	appName: APP_NAME,
	welcome: "Добро пожаловать в TeleChat!",
	welcomeSub: "Сообщения, голос и медиа — всё на одном экране.",
	emailTitle: "Вход в TeleChat",
	emailHint: "Укажите почту — отправим код подтверждения.",
	emailPlaceholder: "you@mail.com",
	continue: "Продолжить",
	codeTitle: "Код подтверждения",
	codeHint: "Мы отправили 4-значный код на",
	codeDemo: "Для демо используйте код 1234",
	usernameTitle: "Как к вам обращаться?",
	usernameHint: "Имя видно в чатах. Юзернейм нужен, чтобы вас находили.",
	namePlaceholder: "Имя",
	usernamePlaceholder: "username",
	start: "Начать",
	chats: "Чаты",
	contacts: "Контакты",
	settings: "Настройки",
	profile: "Профиль",
	searchChats: "Поиск по чатам",
	searchContacts: "Поиск контактов и @username",
	newChat: "Новый чат",
	newGroup: "Новая группа",
	archive: "Архив",
	archived: "Архив чатов",
	mute: "Отключить уведомления",
	unmute: "Включить уведомления",
	pin: "Закрепить",
	unpin: "Открепить",
	delete: "Удалить",
	deleteForMe: "Удалить у себя",
	deleteForAll: "Удалить у всех",
	copy: "Копировать",
	forward: "Переслать",
	reply: "Ответить",
	messagePlaceholder: "Сообщение",
	emptyChats: "Пока нет переписок",
	emptyChatsHint: "Начните чат с контакта или создайте группу.",
	emptyContacts: "Никого не нашлось",
	emptyArchive: "Архив пуст",
	emptyMessages: "Напишите первое сообщение",
	inDevelopment: "Эта функция в разработке",
	online: "в сети",
	typing: "печатает",
	members: "участников",
	save: "Сохранить",
	cancel: "Отмена",
	done: "Готово",
	logout: "Выйти",
	lock: "Заблокировать",
	setPin: "Код-пароль",
	pinHint: "Шесть цифр для быстрого доступа",
	devices: "Устройства",
	theme: "Оформление",
	dark: "Тёмная",
	light: "Светлая",
	editName: "Имя",
	editUsername: "Имя пользователя",
	editBio: "О себе",
	avatar: "Аватар",
	fromGallery: "Из галереи",
	animals: "Животные",
	notifications: "Уведомления",
	privacy: "Конфиденциальность",
	appearance: "Оформление",
	dataStorage: "Данные и память",
	language: "Язык",
	help: "Помощь",
	about: "О TeleChat",
	voiceNote: "Голосовое сообщение",
	photo: "Фото",
	video: "Видео",
	you: "Вы",
	today: "Сегодня",
	yesterday: "Вчера",
	justNow: "только что",
	groupName: "Название группы",
	addMembers: "Участники",
	create: "Создать",
	noResults: "Ничего не найдено",
	copied: "Скопировано",
	deleted: "Сообщение удалено",
	forwarded: "Переслано",
	sent: "Отправлено",
	delivered: "Доставлено",
	read: "Прочитано",
	blocked: "В чёрном списке",
	unblock: "Разблокировать",
	block: "Заблокировать",
	lastSeen: "был(а)",
	enterPin: "Введите код-пароль",
	wrongPin: "Неверный код",
	wrongCode: "Неверный код. Для демо введите 1234",
	invalidEmail: "Проверьте адрес почты",
	invalidName: "Имя не может быть пустым",
	invalidUsername: "Юзернейм: 5–32 символа, латиница, цифры и _",
	usernameTaken: "Этот юзернейм уже занят",
	chatDeleted: "Чат удалён",
	chatArchived: "Чат в архиве",
	notificationsOff: "Уведомления выключены",
	notificationsOn: "Уведомления включены",
	selectChat: "Выберите чат",
	selectChatHint: "Или создайте новый — справа ничего нет, пока вы не откроете переписку.",
	mediaEmpty: "В этом чате ещё нет медиа",
	attach: "Вложение",
	record: "Запись",
	send: "Отправить",
	stop: "Стоп",
	currentDevice: "Это устройство",
	terminate: "Завершить сеанс",
	russian: "Русский",
	fontSize: "Размер шрифта",
	wallpaper: "Фон чата",
	readReceipts: "Отчёты о прочтении",
	lastSeenPrivacy: "Время последнего визита",
	sound: "Звук уведомлений",
	everyone: "Все",
	contactsOnly: "Контакты",
	nobody: "Никто",
	small: "Меньше",
	medium: "Обычно",
	large: "Крупнее",
	version: "Версия 1.0",
	official: "официальный",
	groupCreated: "Группа создана",
	youDeletedChat: "Вы удалили этот чат",
	messageCopied: "Текст скопирован",
	holdToRecord: "Удерживайте, чтобы записать",
	slideToCancel: "Отпустите, чтобы отправить"
};
function createId(prefix = "id") {
	const rand = typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID().slice(0, 8) : Math.random().toString(36).slice(2, 10);
	return `${prefix}_${Date.now().toString(36)}_${rand}`;
}
var ME_ID = "user_me";
var TEAM_ID = "user_telechat";
function hueFromString(value) {
	let hash = 0;
	for (let i = 0; i < value.length; i += 1) hash = hash * 31 + value.charCodeAt(i) >>> 0;
	return hash % 360;
}
function initialsFromName(name) {
	const parts = name.trim().split(/\s+/).filter(Boolean);
	if (parts.length === 0) return "?";
	if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
	return `${parts[0][0] ?? ""}${parts[1][0] ?? ""}`.toUpperCase();
}
function readPersisted() {
	if (typeof window === "undefined") return null;
	try {
		const raw = window.localStorage.getItem(STORAGE_KEY);
		if (!raw) return null;
		const parsed = JSON.parse(raw);
		if (!parsed || parsed.version !== 1) return null;
		return parsed;
	} catch {
		return null;
	}
}
function writePersisted(state) {
	if (typeof window === "undefined") return;
	try {
		window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
	} catch (error) {
		console.warn("[telechat] persist failed", error);
		try {
			const slim = {
				...state,
				messages: Object.fromEntries(Object.entries(state.messages).map(([id, list]) => [id, list.map((m) => m.type === "photo" || m.type === "video" || m.type === "voice" ? {
					...m,
					photo: void 0,
					video: void 0,
					voice: void 0,
					text: m.text || "Медиа"
				} : m)]))
			};
			window.localStorage.setItem(STORAGE_KEY, JSON.stringify(slim));
		} catch {}
	}
}
function clearPersisted() {
	if (typeof window === "undefined") return;
	window.localStorage.removeItem(STORAGE_KEY);
}
var memoryMedia = /* @__PURE__ */ new Map();
function openMediaDb() {
	if (typeof indexedDB === "undefined") return Promise.resolve(null);
	return new Promise((resolve) => {
		try {
			const req = indexedDB.open("telechat-blobs", 1);
			req.onupgradeneeded = () => {
				const db = req.result;
				if (!db.objectStoreNames.contains("media")) db.createObjectStore("media");
			};
			req.onsuccess = () => resolve(req.result);
			req.onerror = () => resolve(null);
		} catch {
			resolve(null);
		}
	});
}
async function putMedia(id, dataUrl) {
	memoryMedia.set(id, dataUrl);
	const db = await openMediaDb();
	if (!db) {
		try {
			localStorage.setItem(`telechat.media.${id}`, dataUrl);
		} catch {}
		return;
	}
	await new Promise((resolve) => {
		const tx = db.transaction("media", "readwrite");
		tx.objectStore("media").put(dataUrl, id);
		tx.oncomplete = () => resolve();
		tx.onerror = () => resolve();
	});
}
async function getMedia(id) {
	if (memoryMedia.has(id)) return memoryMedia.get(id) ?? null;
	const db = await openMediaDb();
	if (!db) try {
		return localStorage.getItem(`telechat.media.${id}`);
	} catch {
		return null;
	}
	return new Promise((resolve) => {
		const req = db.transaction("media", "readonly").objectStore("media").get(id);
		req.onsuccess = () => {
			const value = req.result ?? null;
			if (value) memoryMedia.set(id, value);
			resolve(value);
		};
		req.onerror = () => resolve(null);
	});
}
function peaksFromSamples(samples, buckets = 36) {
	if (samples.length === 0) return Array.from({ length: buckets }, () => .15);
	const size = Math.max(1, Math.floor(samples.length / buckets));
	const peaks = [];
	for (let i = 0; i < buckets; i += 1) {
		let max = 0;
		const start = i * size;
		for (let j = start; j < start + size && j < samples.length; j += 1) max = Math.max(max, Math.abs(samples[j]));
		peaks.push(Math.max(.08, Math.min(1, max)));
	}
	return peaks;
}
function fakePeaks(seed, buckets = 36) {
	const peaks = [];
	let x = seed || 1;
	for (let i = 0; i < buckets; i += 1) {
		x = x * 16807 % 2147483647;
		const wave = .35 + .55 * Math.abs(Math.sin(i / 2.7 + seed));
		peaks.push(Math.max(.1, Math.min(1, wave * (.55 + x % 100 / 180))));
	}
	return peaks;
}
async function blobToDataUrl(blob) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(String(reader.result ?? ""));
		reader.onerror = () => reject(reader.error);
		reader.readAsDataURL(blob);
	});
}
async function storeVoiceBlob(blob, durationMs, peaks) {
	const mediaId = createId("voc");
	await putMedia(mediaId, await blobToDataUrl(blob));
	return {
		mediaId,
		durationMs,
		peaks
	};
}
function createRecorder() {
	let recorder = null;
	let chunks = [];
	let started = 0;
	let stream = null;
	let peaks = [];
	let analyser = null;
	let audioCtx = null;
	let raf = 0;
	const samples = [];
	const tick = () => {
		if (!analyser) return;
		const buf = new Uint8Array(analyser.fftSize);
		analyser.getByteTimeDomainData(buf);
		let peak = 0;
		for (let i = 0; i < buf.length; i += 1) peak = Math.max(peak, Math.abs(buf[i] - 128) / 128);
		samples.push(peak);
		raf = requestAnimationFrame(tick);
	};
	return {
		async start() {
			stream = await navigator.mediaDevices.getUserMedia({ audio: true });
			audioCtx = new AudioContext();
			const source = audioCtx.createMediaStreamSource(stream);
			analyser = audioCtx.createAnalyser();
			analyser.fftSize = 256;
			source.connect(analyser);
			chunks = [];
			samples.length = 0;
			started = Date.now();
			const mime = MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm" : "";
			recorder = new MediaRecorder(stream, mime ? { mimeType: mime } : void 0);
			recorder.ondataavailable = (event) => {
				if (event.data.size > 0) chunks.push(event.data);
			};
			recorder.start(80);
			tick();
		},
		stop() {
			return new Promise((resolve, reject) => {
				if (!recorder) {
					reject(/* @__PURE__ */ new Error("not recording"));
					return;
				}
				recorder.onstop = () => {
					cancelAnimationFrame(raf);
					stream?.getTracks().forEach((tr) => tr.stop());
					audioCtx?.close();
					peaks = peaksFromSamples(samples);
					resolve({
						blob: new Blob(chunks, { type: recorder?.mimeType || "audio/webm" }),
						durationMs: Date.now() - started,
						peaks
					});
					recorder = null;
				};
				recorder.stop();
			});
		},
		cancel() {
			cancelAnimationFrame(raf);
			try {
				recorder?.stop();
			} catch {}
			stream?.getTracks().forEach((tr) => tr.stop());
			audioCtx?.close();
			recorder = null;
		}
	};
}
function playChime(enabled) {
	if (!enabled || typeof AudioContext === "undefined") return;
	const ctx = new AudioContext();
	const now = ctx.currentTime;
	const osc = ctx.createOscillator();
	const gain = ctx.createGain();
	osc.type = "sine";
	osc.frequency.setValueAtTime(880, now);
	osc.frequency.exponentialRampToValueAtTime(1320, now + .08);
	gain.gain.setValueAtTime(1e-4, now);
	gain.gain.exponentialRampToValueAtTime(.08, now + .02);
	gain.gain.exponentialRampToValueAtTime(1e-4, now + .22);
	osc.connect(gain);
	gain.connect(ctx.destination);
	osc.start(now);
	osc.stop(now + .24);
	osc.onended = () => void ctx.close();
}
var GENERIC = [
	"Ок, понял.",
	"Сейчас гляну и отвечу.",
	"Ха, хорошо.",
	"Давай так.",
	"Напишу чуть позже.",
	"Согласен.",
	"Интересно. Расскажи ещё.",
	"Супер, спасибо!"
];
var KEYWORD_REPLIES = [
	{
		test: /привет|здравств|хай|йоу|добр/i,
		replies: [
			"Привет! Как дела?",
			"Здорово. Рад тебя видеть.",
			"Привет-привет!"
		]
	},
	{
		test: /как дела|что нового|как ты/i,
		replies: [
			"Нормально, в работе. А у тебя?",
			"Всё спокойно. Вечером свободен.",
			"Отлично, только что закончил задачу."
		]
	},
	{
		test: /фото|картин|снимок/i,
		replies: [
			"Классный кадр.",
			"Выглядит здорово.",
			"Ого, круто снято."
		]
	},
	{
		test: /голос|слушай|аудио/i,
		replies: [
			"Прослушал. Ок.",
			"Понял тебя.",
			"Сейчас переслушаю ещё раз."
		]
	},
	{
		test: /встрет|кофе|чай|пойдём|пойдем/i,
		replies: [
			"Давай. Завтра после шести нормально?",
			"Могу в пятницу.",
			"Ок, кидай место."
		]
	},
	{
		test: /\?/,
		replies: [
			"Хороший вопрос. Дай подумать.",
			"Думаю, да.",
			"Скорее нет, но могу уточнить."
		]
	},
	{
		test: /спасибо|благодар/i,
		replies: [
			"Всегда пожалуйста.",
			"Не за что.",
			"Обращайся."
		]
	},
	{
		test: /ок|хорошо|ладно|договорились/i,
		replies: [
			"Отлично.",
			"Договорились.",
			"Жду."
		]
	}
];
var PERSONALITY = {
	user_anna: [
		"Макет уже в Figma, кину ссылку вечером.",
		"Давай без лишнего — короткий текст на карточке.",
		"Цвет акцента лучше чуть холоднее."
	],
	user_dmitry: [
		"Ха, это сильно.",
		"Пойдём в зал в четверг?",
		"Кинь адрес, я рядом."
	],
	user_mom: [
		"Ты поел?",
		"Хорошо, родной. Не засиживайся.",
		"Позвони, как будешь свободен."
	],
	user_elena: [
		"Статус по задаче: в работе, вечером обновлю доску.",
		"Нужен апдейт к 18:00.",
		"Согласую с командой и вернусь."
	],
	user_max: [
		"Сегодня 5×5, потом кардио.",
		"Не забудь протеин.",
		"Завтра в 7:30 у входа."
	],
	user_sofia: [
		"Конспект скину после пары.",
		"Там на слайде 14 как раз это.",
		"Можем созвониться на 20 минут."
	],
	user_alexey: [
		"Я на этаже, если что — стучи.",
		"Почта в ящике, кстати.",
		"Вечером тихо будет, ремонт закончили."
	],
	user_irina: [
		"Мама уже спрашивала, когда ты приедешь.",
		"Фото с выходных просто огонь.",
		"Купи хлеб, если будешь в магазине."
	],
	user_nikita: [
		"Го в катку после девяти.",
		"Патч вышел, там нерфнули ту пушку.",
		"GG, реванш?"
	],
	user_telechat: [
		"Это автоматическое сообщение TeleChat. Мы рядом, если что-то сломается.",
		"Подсказка: зажмите сообщение, чтобы поставить реакцию.",
		"Код-пароль можно включить в Настройках."
	]
};
function pickReply(contact, text) {
	for (const rule of KEYWORD_REPLIES) if (rule.test.test(text)) return pick(rule.replies, contact.id);
	const personal = PERSONALITY[contact.id];
	if (personal && Math.random() > .35) return pick(personal, text.length);
	return pick(GENERIC, contact.id.length + text.length);
}
function pickGroupReply(senderName, text) {
	const replies = [
		`${senderName}, плюсую.`,
		"Давайте зафиксируем это.",
		"Могу взять на себя.",
		"Ок, тогда без меня завтра — пишите итог.",
		"Звучит разумно."
	];
	if (/\?/.test(text)) replies.unshift("Могу уточнить и написать сюда.");
	return {
		speakerOffset: (text.length + senderName.length) % 3,
		text: pick(replies, text.length)
	};
}
function pick(list, seed) {
	const n = typeof seed === "number" ? seed : Array.from(String(seed)).reduce((a, c) => a + c.charCodeAt(0), 0);
	return list[Math.abs(n) % list.length] ?? list[0];
}
function replyDelay(online) {
	if (online) return 700 + Math.floor(Math.random() * 1100);
	return 1400 + Math.floor(Math.random() * 2200);
}
function fileToDataUrl(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(String(reader.result ?? ""));
		reader.onerror = () => reject(reader.error);
		reader.readAsDataURL(file);
	});
}
async function compressImageFile(file) {
	return compressDataUrl(await fileToDataUrl(file));
}
function compressDataUrl(dataUrl, maxEdge = MAX_IMAGE_EDGE, quality = .72) {
	return new Promise((resolve) => {
		const img = new Image();
		img.onload = () => {
			const scale = Math.min(1, maxEdge / Math.max(img.width, img.height));
			const width = Math.max(1, Math.round(img.width * scale));
			const height = Math.max(1, Math.round(img.height * scale));
			const canvas = document.createElement("canvas");
			canvas.width = width;
			canvas.height = height;
			const ctx = canvas.getContext("2d");
			if (!ctx) {
				resolve({
					dataUrl,
					width: img.width,
					height: img.height
				});
				return;
			}
			ctx.drawImage(img, 0, 0, width, height);
			resolve({
				dataUrl: canvas.toDataURL("image/jpeg", quality),
				width,
				height
			});
		};
		img.onerror = () => resolve({
			dataUrl,
			width: 1,
			height: 1
		});
		img.src = dataUrl;
	});
}
async function storeImageFile(file) {
	const compressed = await compressImageFile(file);
	const mediaId = createId("img");
	await putMedia(mediaId, compressed.dataUrl);
	return {
		mediaId,
		width: compressed.width,
		height: compressed.height
	};
}
async function storeVideoFile(file) {
	const dataUrl = await fileToDataUrl(file);
	const mediaId = createId("vid");
	await putMedia(mediaId, dataUrl);
	return {
		mediaId,
		...await readVideoMeta(dataUrl)
	};
}
function readVideoMeta(src) {
	return new Promise((resolve) => {
		const video = document.createElement("video");
		video.preload = "metadata";
		video.onloadedmetadata = () => {
			resolve({
				durationMs: Math.round((video.duration || 0) * 1e3),
				width: video.videoWidth || 640,
				height: video.videoHeight || 360
			});
		};
		video.onerror = () => resolve({
			durationMs: 0,
			width: 640,
			height: 360
		});
		video.src = src;
	});
}
function makePatternPhoto(seed, w = 720, h = 480) {
	const hue = Array.from(seed).reduce((a, c) => a + c.charCodeAt(0), 0) % 360;
	const hue2 = (hue + 38) % 360;
	const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}">
    <defs>
      <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="hsl(${hue} 38% 28%)"/>
        <stop offset="1" stop-color="hsl(${hue2} 32% 16%)"/>
      </linearGradient>
    </defs>
    <rect width="${w}" height="${h}" fill="url(#g)"/>
    <circle cx="${w * .72}" cy="${h * .28}" r="${h * .22}" fill="hsl(${hue} 50% 62% / 0.35)"/>
    <circle cx="${w * .22}" cy="${h * .7}" r="${h * .18}" fill="hsl(${hue2} 40% 70% / 0.22)"/>
    <rect x="${w * .12}" y="${h * .18}" width="${w * .28}" height="${h * .08}" rx="8" fill="white" fill-opacity="0.12"/>
  </svg>`;
	return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}
var HOUR = 36e5;
var MIN = 6e4;
function ago(hours, minutes = 0) {
	return Date.now() - hours * HOUR - minutes * MIN;
}
function gradient(name) {
	return {
		kind: "gradient",
		hue: hueFromString(name),
		initials: initialsFromName(name)
	};
}
function animal(id) {
	return {
		kind: "animal",
		animal: id
	};
}
function defaultProfile(email, displayName, username) {
	return {
		id: ME_ID,
		email,
		displayName,
		username,
		avatar: gradient(displayName),
		bio: "Привет, я в TeleChat.",
		pin: null,
		createdAt: Date.now(),
		lastSeenPrivacy: "everyone",
		readReceipts: true,
		notificationSound: true,
		saveToGallery: false,
		fontSize: "medium"
	};
}
function seedContacts() {
	return [
		{
			id: TEAM_ID,
			displayName: "TeleChat",
			username: "telechat",
			avatar: {
				kind: "gradient",
				hue: 199,
				initials: "TC"
			},
			bio: "Официальный аккаунт сервиса. Подсказки, новости и поддержка.",
			lastSeen: Date.now(),
			online: true,
			typing: false,
			isOfficial: true,
			city: "TeleChat Cloud"
		},
		{
			id: "user_anna",
			displayName: "Анна Волкова",
			username: "anna_volkova",
			avatar: animal("fox"),
			bio: "Дизайн · продукт · Figma",
			lastSeen: ago(0, 4),
			online: true,
			typing: false,
			city: "Москва",
			phone: "+7 900 111-22-33"
		},
		{
			id: "user_dmitry",
			displayName: "Дмитрий Орлов",
			username: "orlovd",
			avatar: animal("wolf"),
			bio: "Снимаю город и пью слишком много кофе.",
			lastSeen: ago(0, 18),
			online: true,
			typing: false,
			city: "Санкт-Петербург"
		},
		{
			id: "user_mom",
			displayName: "Мама",
			username: "marina_k",
			avatar: animal("cat"),
			bio: "Звони, не пиши.",
			lastSeen: ago(2, 10),
			online: false,
			typing: false,
			city: "Казань"
		},
		{
			id: "user_elena",
			displayName: "Елена Соколова",
			username: "sokolova",
			avatar: gradient("Елена Соколова"),
			bio: "Проджект. Дедлайны люблю больше, чем сюрпризы.",
			lastSeen: ago(0, 40),
			online: false,
			typing: false,
			city: "Москва"
		},
		{
			id: "user_max",
			displayName: "Максим Петров",
			username: "maxlift",
			avatar: animal("bear"),
			bio: "Сила. Режим. Без оправданий.",
			lastSeen: ago(1, 5),
			online: false,
			typing: false,
			city: "Екатеринбург"
		},
		{
			id: "user_sofia",
			displayName: "София Иванова",
			username: "sofi_i",
			avatar: animal("rabbit"),
			bio: "Аспирантура и бесконечные слайды.",
			lastSeen: ago(0, 12),
			online: true,
			typing: false,
			city: "Новосибирск"
		},
		{
			id: "user_alexey",
			displayName: "Алексей Новиков",
			username: "novikov",
			avatar: animal("owl"),
			bio: "Сосед справа, если что.",
			lastSeen: ago(5, 0),
			online: false,
			typing: false,
			city: "Москва"
		},
		{
			id: "user_irina",
			displayName: "Ирина",
			username: "irina_s",
			avatar: animal("otter"),
			bio: "Сестра. Возвращаю зарядки.",
			lastSeen: ago(3, 20),
			online: false,
			typing: false,
			city: "Казань"
		},
		{
			id: "user_nikita",
			displayName: "Никита Громов",
			username: "gromov",
			avatar: animal("tiger"),
			bio: "Катки, патчи, мемы.",
			lastSeen: ago(0, 7),
			online: true,
			typing: false,
			city: "Краснодар"
		},
		{
			id: "user_kira",
			displayName: "Кира Лебедева",
			username: "lebedeva",
			avatar: animal("bird"),
			bio: "Редактор. Правлю чужие запятые.",
			lastSeen: ago(8, 0),
			online: false,
			typing: false,
			city: "Москва"
		},
		{
			id: "user_timur",
			displayName: "Тимур Сафин",
			username: "safin",
			avatar: animal("whale"),
			bio: "Бэкенд, деплой, спокойствие.",
			lastSeen: ago(6, 30),
			online: false,
			typing: false,
			city: "Казань"
		},
		{
			id: "user_olga",
			displayName: "Ольга Белова",
			username: "belova",
			avatar: gradient("Ольга Белова"),
			bio: "Фотограф выходного дня.",
			lastSeen: ago(26, 0),
			online: false,
			typing: false,
			city: "Сочи"
		}
	];
}
function buildMessages(chatId, lines) {
	return lines.map((line, index) => {
		const createdAt = ago(line.hours, line.minutes ?? 0);
		const senderId = line.from === "me" ? ME_ID : line.from;
		const type = line.kind ?? "text";
		const message = {
			id: `${chatId}_m${index + 1}`,
			chatId,
			senderId,
			type,
			text: line.text ?? "",
			createdAt,
			editedAt: null,
			status: senderId === "user_me" ? "read" : "delivered",
			replyToId: null,
			forwarded: null,
			reactions: line.reactions ?? {},
			deletedForMe: false,
			deletedForAll: false
		};
		if (type === "voice") {
			message.voice = {
				mediaId: `${chatId}_voice_${index}`,
				durationMs: (line.duration ?? 8) * 1e3,
				peaks: fakePeaks(index + chatId.length, 32)
			};
			message.text = "";
		}
		if (type === "photo") message.photo = {
			mediaId: `${chatId}_photo_${index}`,
			width: 720,
			height: 480,
			caption: line.text
		};
		return message;
	});
}
function seedChatsAndMessages(contacts) {
	const byId = Object.fromEntries(contacts.map((c) => [c.id, c]));
	const messages = {};
	return {
		chats: [
			{
				id: "chat_team",
				type: "direct",
				participants: [ME_ID, TEAM_ID],
				pinned: true,
				unread: 1,
				lines: [
					{
						from: TEAM_ID,
						hours: 48,
						text: "Это TeleChat. Здесь ваши чаты, группы и медиа — всё хранится на устройстве."
					},
					{
						from: TEAM_ID,
						hours: 48,
						minutes: -2,
						text: "Подсказка: зажмите сообщение, чтобы поставить реакцию, переслать или удалить."
					},
					{
						from: "me",
						hours: 47,
						text: "Понял, спасибо."
					},
					{
						from: TEAM_ID,
						hours: 0,
						minutes: 8,
						text: "Код подтверждения для демо всегда 1234. Добро пожаловать в TeleChat!"
					}
				]
			},
			{
				id: "chat_anna",
				type: "direct",
				participants: [ME_ID, "user_anna"],
				unread: 2,
				lines: [
					{
						from: "user_anna",
						hours: 30,
						text: "Кинула первую сетку экранов в общую папку."
					},
					{
						from: "me",
						hours: 29,
						text: "Смотрю. Нижняя навигация очень к месту."
					},
					{
						from: "user_anna",
						hours: 29,
						minutes: -8,
						text: "Да, и скругления 20/28 — не мельчить."
					},
					{
						from: "user_anna",
						hours: 5,
						text: "Сверила контраст на тёмной теме. Акцент не орёт, читается.",
						reactions: { like: [ME_ID] }
					},
					{
						from: "me",
						hours: 4,
						text: "Супер. Давай вечером пройдёмся по пустым состояниям."
					},
					{
						from: "user_anna",
						hours: 0,
						minutes: 12,
						text: "Ок. Ещё набросала экран профиля — глянь, пожалуйста."
					},
					{
						from: "user_anna",
						hours: 0,
						minutes: 11,
						text: "И юзернейм лучше проверять на латиницу сразу, не после сабмита."
					}
				]
			},
			{
				id: "chat_dmitry",
				type: "direct",
				participants: [ME_ID, "user_dmitry"],
				lines: [
					{
						from: "user_dmitry",
						hours: 52,
						text: "Ты видел свет на набережной вчера?"
					},
					{
						from: "me",
						hours: 51,
						text: "Нет, расскажи."
					},
					{
						from: "user_dmitry",
						hours: 51,
						kind: "photo",
						photoSeed: "neva",
						text: "Вот, без обработки."
					},
					{
						from: "me",
						hours: 50,
						text: "Живой кадр. Можно в ленту."
					},
					{
						from: "user_dmitry",
						hours: 8,
						text: "Кофе на Мойке в субботу? Часов в 12."
					},
					{
						from: "me",
						hours: 7,
						text: "Давай. Я как раз в центре."
					},
					{
						from: "user_dmitry",
						hours: 1,
						minutes: 20,
						text: "Отлично. Если дождь — то в «Волне», там тихо.",
						reactions: { fire: [ME_ID] }
					}
				]
			},
			{
				id: "chat_mom",
				type: "direct",
				participants: [ME_ID, "user_mom"],
				muted: true,
				lines: [
					{
						from: "user_mom",
						hours: 70,
						text: "Ты долетел нормально?"
					},
					{
						from: "me",
						hours: 69,
						text: "Да, всё хорошо. Уже дома."
					},
					{
						from: "user_mom",
						hours: 20,
						text: "Не забудь витамины, которые я клала в рюкзак."
					},
					{
						from: "me",
						hours: 19,
						text: "Нашёл, спасибо."
					},
					{
						from: "user_mom",
						hours: 6,
						text: "Приедешь на выходных? Папа спрашивает."
					},
					{
						from: "me",
						hours: 5,
						text: "Попробую в воскресенье к обеду."
					},
					{
						from: "user_mom",
						hours: 5,
						minutes: -4,
						text: "Хорошо. Куплю пирог."
					}
				]
			},
			{
				id: "chat_elena",
				type: "direct",
				participants: [ME_ID, "user_elena"],
				unread: 1,
				lines: [
					{
						from: "user_elena",
						hours: 26,
						text: "Нужен статус по северному контуру к 18:00."
					},
					{
						from: "me",
						hours: 25,
						text: "Соберу. Блокер только по анимации списка — Анна правит."
					},
					{
						from: "user_elena",
						hours: 25,
						text: "Ок, в заметке к стендапу это укажи."
					},
					{
						from: "user_elena",
						hours: 3,
						text: "Клиент перенёс демо на четверг. Дышим."
					},
					{
						from: "me",
						hours: 3,
						minutes: -10,
						text: "Принял. Обновлю доску."
					},
					{
						from: "user_elena",
						hours: 0,
						minutes: 33,
						text: "И ещё: не забудь выключить фейковые лоадеры перед записью."
					}
				]
			},
			{
				id: "chat_max",
				type: "direct",
				participants: [ME_ID, "user_max"],
				lines: [
					{
						from: "user_max",
						hours: 40,
						text: "Завтра грудь/трицепс. Не опаздывай."
					},
					{
						from: "me",
						hours: 39,
						text: "Буду к 7:30."
					},
					{
						from: "user_max",
						hours: 14,
						kind: "voice",
						duration: 11
					},
					{
						from: "me",
						hours: 13,
						text: "Понял, без жима лёжа в начале — тогда тяга."
					},
					{
						from: "user_max",
						hours: 2,
						text: "Протеиновый торт это не восстановление. Не надо."
					}
				]
			},
			{
				id: "chat_sofia",
				type: "direct",
				participants: [ME_ID, "user_sofia"],
				lines: [
					{
						from: "user_sofia",
						hours: 18,
						text: "Скинула конспект по второй главе."
					},
					{
						from: "me",
						hours: 17,
						text: "Дошёл. Там на 14 слайде как раз спорный график."
					},
					{
						from: "user_sofia",
						hours: 17,
						text: "Да, я тоже на этом месте споткнулась."
					},
					{
						from: "user_sofia",
						hours: 4,
						text: "Можем разобрать это завтра после семинара?"
					},
					{
						from: "me",
						hours: 4,
						minutes: -6,
						text: "Да, 15 минут хватит."
					}
				]
			},
			{
				id: "chat_nikita",
				type: "direct",
				participants: [ME_ID, "user_nikita"],
				lines: [
					{
						from: "user_nikita",
						hours: 12,
						text: "Патч вышел. Ту пушку нерфнули, как я и говорил."
					},
					{
						from: "me",
						hours: 11,
						text: "Значит играем от мобильности."
					},
					{
						from: "user_nikita",
						hours: 3,
						text: "Го после девяти. Нужен четвёртый."
					},
					{
						from: "me",
						hours: 2,
						text: "Если успею с работой — буду."
					},
					{
						from: "user_nikita",
						hours: 0,
						minutes: 50,
						text: "Ок. Если нет — возьму бота, но это уже не то.",
						reactions: { laugh: [ME_ID] }
					}
				]
			},
			{
				id: "chat_irina",
				type: "direct",
				participants: [ME_ID, "user_irina"],
				lines: [
					{
						from: "user_irina",
						hours: 60,
						text: "Ты опять унёс зарядку."
					},
					{
						from: "me",
						hours: 59,
						text: "Верну в воскресенье. Честно."
					},
					{
						from: "user_irina",
						hours: 9,
						kind: "photo",
						photoSeed: "family",
						text: "Это с дачи, папа гриль завёл с третьего раза."
					},
					{
						from: "me",
						hours: 8,
						text: "Классика."
					}
				]
			},
			{
				id: "chat_alexey",
				type: "direct",
				participants: [ME_ID, "user_alexey"],
				archived: true,
				lines: [
					{
						from: "user_alexey",
						hours: 90,
						text: "Курьер оставил коробку у двери. Это тебе?"
					},
					{
						from: "me",
						hours: 89,
						text: "Да, заберу вечером. Спасибо."
					},
					{
						from: "user_alexey",
						hours: 88,
						text: "Ок. Если что — я до девяти дома."
					}
				]
			},
			{
				id: "chat_kira",
				type: "direct",
				participants: [ME_ID, "user_kira"],
				lines: [
					{
						from: "user_kira",
						hours: 34,
						text: "В тексте онбординга лучше «код подтверждения», не «пин из письма»."
					},
					{
						from: "me",
						hours: 33,
						text: "Согласен. Поправлю."
					},
					{
						from: "user_kira",
						hours: 10,
						text: "И точку после приветствия можно убрать — теплее звучит."
					}
				]
			},
			{
				id: "chat_project",
				type: "group",
				title: "Проект Север",
				participants: [
					ME_ID,
					"user_anna",
					"user_elena",
					"user_timur"
				],
				avatar: {
					kind: "gradient",
					hue: 204,
					initials: "ПС"
				},
				description: "Рабочий контур. Макеты, статусы, без мемов.",
				unread: 3,
				lines: [
					{
						from: "user_elena",
						hours: 28,
						text: "Стендап в 10:15. Коротко: блокеры и план на день."
					},
					{
						from: "user_timur",
						hours: 27,
						text: "Деплой на превью зелёный. Логи чистые."
					},
					{
						from: "user_anna",
						hours: 27,
						text: "Пусшу иконки навбара и состояния пустого списка."
					},
					{
						from: "me",
						hours: 26,
						text: "Беру чат и реакции. Голос пишу на нативном рекордере."
					},
					{
						from: "user_elena",
						hours: 4,
						text: "Клиент перенёс демо. Есть воздух — давайте добьём полировку."
					},
					{
						from: "user_anna",
						hours: 1,
						text: "Пустые состояния центрирую, без иллюстраций-заглушек."
					},
					{
						from: "user_timur",
						hours: 0,
						minutes: 25,
						text: "На превью проверьте тёмную и светлую, я уже видел скачок контраста у исходящих."
					},
					{
						from: "user_elena",
						hours: 0,
						minutes: 22,
						text: "Фиксируем: сегодня только полировка, новые фичи не трогаем."
					}
				]
			},
			{
				id: "chat_family",
				type: "group",
				title: "Семья",
				participants: [
					ME_ID,
					"user_mom",
					"user_irina"
				],
				avatar: animal("deer"),
				muted: true,
				description: "Домашние дела и пироги.",
				lines: [
					{
						from: "user_mom",
						hours: 46,
						text: "Воскресенье, обед. Кто едет?"
					},
					{
						from: "user_irina",
						hours: 45,
						text: "Я буду. Куплю зелень."
					},
					{
						from: "me",
						hours: 44,
						text: "Я к двум, если электричка не подведёт."
					},
					{
						from: "user_mom",
						hours: 12,
						text: "Пирог с капустой и с яблоком. Не спорьте."
					},
					{
						from: "user_irina",
						hours: 11,
						kind: "photo",
						photoSeed: "pie",
						text: "Яблочный уже в духовке, репетиция."
					}
				]
			},
			{
				id: "chat_hike",
				type: "group",
				title: "Поход 2026",
				participants: [
					ME_ID,
					"user_dmitry",
					"user_max",
					"user_olga",
					"user_nikita"
				],
				avatar: animal("frog"),
				description: "Маршрут, палаткa, кто несёт кастрюлю.",
				lines: [
					{
						from: "user_olga",
						hours: 80,
						text: "Если идём в июне — беру камеру и запасные аккумуляторы."
					},
					{
						from: "user_dmitry",
						hours: 79,
						text: "Маршрут вдоль хребта, без геройства в первый день."
					},
					{
						from: "user_max",
						hours: 78,
						text: "Кастрюлю несу я. Кто-то — газ."
					},
					{
						from: "me",
						hours: 77,
						text: "Газ и аптечка на мне."
					},
					{
						from: "user_nikita",
						hours: 16,
						text: "Пауэрбанк на 30 тысяч, иначе карта умрёт."
					},
					{
						from: "user_olga",
						hours: 6,
						kind: "photo",
						photoSeed: "ridge",
						text: "Вот такой свет хочу поймать."
					}
				]
			}
		].map((script) => {
			const list = buildMessages(script.id, script.lines);
			messages[script.id] = list;
			const last = list[list.length - 1];
			const other = script.participants.find((id) => id !== ME_ID);
			const contact = other ? byId[other] : void 0;
			const title = script.type === "group" ? script.title ?? "Группа" : contact?.displayName ?? "Чат";
			const avatar = script.avatar ?? contact?.avatar ?? gradient(title);
			return {
				id: script.id,
				type: script.type,
				title,
				avatar,
				participantIds: script.participants,
				lastMessagePreview: previewFrom(last),
				lastMessageAt: last?.createdAt ?? Date.now(),
				unread: script.unread ?? 0,
				muted: script.muted ?? false,
				archived: script.archived ?? false,
				pinned: script.pinned ?? false,
				pinnedMessageId: null,
				createdAt: list[0]?.createdAt ?? Date.now(),
				createdBy: ME_ID,
				deletedForMe: false,
				description: script.description
			};
		}),
		messages
	};
}
function previewFrom(message) {
	if (!message || message.deletedForAll) return "";
	if (message.type === "voice") return "Голосовое сообщение";
	if (message.type === "photo") return message.photo?.caption || "Фото";
	if (message.type === "video") return message.video?.caption || "Видео";
	if (message.type === "system") return message.text;
	return message.text;
}
async function hydrateSeedMedia(messages) {
	const jobs = [];
	for (const list of Object.values(messages)) for (const message of list) if (message.photo) jobs.push(putMedia(message.photo.mediaId, makePatternPhoto(message.photo.mediaId)));
	await Promise.all(jobs);
}
function seedDevices() {
	const ua = typeof navigator === "undefined" ? "Web" : navigator.userAgent;
	return [
		{
			id: "dev_current",
			name: /Mac/i.test(ua) ? "Safari · Mac" : /iPhone/i.test(ua) ? "TeleChat iOS" : /Android/i.test(ua) ? "Chrome · Android" : "TeleChat Web",
			platform: "web",
			location: "Москва",
			lastActive: Date.now(),
			current: true,
			ip: "127.0.0.1"
		},
		{
			id: "dev_iphone",
			name: "iPhone 16 Pro",
			platform: "ios",
			location: "Москва",
			lastActive: ago(8, 12),
			current: false,
			ip: "185.22.10.4"
		},
		{
			id: "dev_mac",
			name: "TeleChat Desktop",
			platform: "desktop",
			location: "Казань",
			lastActive: ago(40, 0),
			current: false,
			ip: "95.24.11.8"
		}
	];
}
var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
var USERNAME_RE = /^[a-zA-Z][a-zA-Z0-9_]{4,31}$/;
var PIN_RE = /^\d{6}$/;
function isValidEmail(value) {
	return EMAIL_RE.test(value.trim());
}
function normalizeUsername(value) {
	return value.trim().replace(/^@/, "").toLowerCase();
}
function isValidUsername(value) {
	const v = normalizeUsername(value);
	if (v.length < 5 || v.length > 32) return false;
	return USERNAME_RE.test(v);
}
function isValidDisplayName(value) {
	const v = value.trim();
	return v.length >= 2 && v.length <= 48;
}
function isValidPin(value) {
	return PIN_RE.test(value) && value.length === 6;
}
function isValidCode(value, expected) {
	return value.trim() === expected;
}
function usernameError(value) {
	const v = normalizeUsername(value);
	if (!v) return "Укажите юзернейм";
	if (v.length < 5) return "Минимум 5 символов";
	if (v.length > 32) return "Максимум 32 символа";
	if (!/^[a-zA-Z]/.test(v)) return "Должен начинаться с буквы";
	if (!/^[a-zA-Z0-9_]+$/.test(v)) return "Только латиница, цифры и _";
	return null;
}
var emptyUi = () => ({
	tab: "chats",
	activeChatId: null,
	chatFilter: "all",
	showArchived: false,
	searchQuery: "",
	contactQuery: "",
	comingSoon: null,
	mediaViewer: null,
	forwardMessageId: null,
	selectedMessageId: null,
	chatInfoOpen: false,
	createMode: null,
	authEmail: "",
	authCode: "",
	authName: "",
	authUsername: "",
	authError: null,
	pinInput: "",
	pinError: null
});
function snapshot(state) {
	return {
		version: 1,
		session: state.session,
		profile: state.profile,
		contacts: state.contacts,
		chats: state.chats,
		messages: state.messages,
		devices: state.devices,
		drafts: state.drafts,
		theme: state.theme,
		blockedIds: state.blockedIds,
		wallpaper: state.wallpaper
	};
}
function applyTheme(theme) {
	if (typeof document === "undefined") return;
	document.documentElement.classList.toggle("dark", theme === "dark");
	document.documentElement.classList.toggle("light", theme === "light");
	document.documentElement.style.colorScheme = theme;
}
var persistTimer = null;
var replyTimers = [];
var useTelechat = create((set, get) => {
	const persistSoon = () => {
		if (persistTimer) clearTimeout(persistTimer);
		persistTimer = setTimeout(() => get().persist(), 80);
	};
	const bumpChat = (chatId, preview, at, unreadInc = 0) => {
		set((state) => ({ chats: state.chats.map((chat) => chat.id === chatId ? {
			...chat,
			lastMessagePreview: preview,
			lastMessageAt: at,
			unread: Math.max(0, chat.unread + unreadInc)
		} : chat) }));
	};
	const appendMessage = (message, unreadInc = 0) => {
		set((state) => ({ messages: {
			...state.messages,
			[message.chatId]: [...state.messages[message.chatId] ?? [], message]
		} }));
		bumpChat(message.chatId, previewFrom(message), message.createdAt, unreadInc);
		persistSoon();
	};
	const scheduleReply = (chatId, text) => {
		const state = get();
		const chat = state.chats.find((c) => c.id === chatId);
		if (!chat) return;
		const others = chat.participantIds.filter((id) => id !== "user_me" && !state.blockedIds.includes(id));
		if (others.length === 0) return;
		const contact = state.contacts.find((c) => c.id === others[0]);
		const delay = replyDelay(contact?.online ?? false);
		set((s) => ({ contacts: s.contacts.map((c) => others.includes(c.id) ? {
			...c,
			typing: true
		} : c) }));
		const timer = setTimeout(() => {
			const latest = get();
			const still = latest.chats.find((c) => c.id === chatId);
			if (!still || still.deletedForMe) return;
			set((s) => ({ contacts: s.contacts.map((c) => others.includes(c.id) ? {
				...c,
				typing: false,
				online: true,
				lastSeen: Date.now()
			} : c) }));
			if (chat.type === "group") {
				const pick = pickGroupReply(latest.profile?.displayName ?? "вы", text);
				const speaker = others[pick.speakerOffset % others.length] ?? others[0];
				latest.contacts.find((c) => c.id === speaker);
				appendMessage(makeMessage({
					chatId,
					senderId: speaker,
					text: pick.text
				}), latest.ui.activeChatId === chatId ? 0 : 1);
				if (latest.ui.activeChatId !== chatId) playChime(latest.profile?.notificationSound ?? true);
			} else if (contact) {
				appendMessage(makeMessage({
					chatId,
					senderId: contact.id,
					text: pickReply(contact, text)
				}), latest.ui.activeChatId === chatId ? 0 : 1);
				if (latest.ui.activeChatId !== chatId) playChime(latest.profile?.notificationSound ?? true);
			}
		}, delay);
		replyTimers.push(timer);
	};
	return {
		hydrated: false,
		theme: "dark",
		session: null,
		profile: null,
		contacts: [],
		chats: [],
		messages: {},
		devices: [],
		drafts: {},
		blockedIds: [],
		wallpaper: "ink",
		ui: emptyUi(),
		authStep: "email",
		async hydrate() {
			const saved = readPersisted();
			if (saved?.profile && saved.session?.onboarded) {
				applyTheme(saved.theme);
				set({
					hydrated: true,
					theme: saved.theme,
					session: saved.session,
					profile: saved.profile,
					contacts: saved.contacts,
					chats: saved.chats,
					messages: saved.messages,
					devices: saved.devices.map((d) => d.current ? {
						...d,
						lastActive: Date.now()
					} : d),
					drafts: saved.drafts,
					blockedIds: saved.blockedIds,
					wallpaper: saved.wallpaper,
					authStep: saved.session.locked ? "app" : "app",
					ui: emptyUi()
				});
				await hydrateSeedMedia(saved.messages);
				return;
			}
			applyTheme("dark");
			set({
				hydrated: true,
				authStep: "email",
				ui: emptyUi()
			});
		},
		persist() {
			const state = get();
			if (!state.hydrated) return;
			writePersisted(snapshot(state));
		},
		setTheme(theme) {
			applyTheme(theme);
			set({ theme });
			persistSoon();
		},
		setTab(tab) {
			set((s) => ({ ui: {
				...s.ui,
				tab,
				showArchived: false
			} }));
		},
		setAuthEmail(value) {
			set((s) => ({ ui: {
				...s.ui,
				authEmail: value,
				authError: null
			} }));
		},
		setAuthCode(value) {
			set((s) => ({ ui: {
				...s.ui,
				authCode: value.replace(/\D/g, "").slice(0, 4),
				authError: null
			} }));
		},
		setAuthName(value) {
			set((s) => ({ ui: {
				...s.ui,
				authName: value,
				authError: null
			} }));
		},
		setAuthUsername(value) {
			set((s) => ({ ui: {
				...s.ui,
				authUsername: normalizeUsername(value),
				authError: null
			} }));
		},
		requestCode() {
			if (!isValidEmail(get().ui.authEmail.trim())) {
				set((s) => ({ ui: {
					...s.ui,
					authError: "Проверьте адрес почты"
				} }));
				return false;
			}
			set({ authStep: "code" });
			return true;
		},
		verifyCode() {
			if (!isValidCode(get().ui.authCode, "1234")) {
				set((s) => ({ ui: {
					...s.ui,
					authError: "Неверный код. Для демо введите 1234"
				} }));
				return false;
			}
			const saved = readPersisted();
			if (saved?.profile && saved.session) {
				applyTheme(saved.theme);
				set({
					session: {
						...saved.session,
						verifiedAt: Date.now(),
						locked: false
					},
					profile: saved.profile,
					contacts: saved.contacts,
					chats: saved.chats,
					messages: saved.messages,
					devices: saved.devices,
					drafts: saved.drafts,
					blockedIds: saved.blockedIds,
					wallpaper: saved.wallpaper,
					theme: saved.theme,
					authStep: "welcome"
				});
				persistSoon();
				return true;
			}
			set({ authStep: "username" });
			return true;
		},
		completeProfile() {
			const { authName, authUsername } = get().ui;
			if (authName.trim().length < 2) {
				set((s) => ({ ui: {
					...s.ui,
					authError: "Имя не может быть пустым"
				} }));
				return false;
			}
			if (!isValidUsername(authUsername)) {
				set((s) => ({ ui: {
					...s.ui,
					authError: "Юзернейм: 5–32 символа, латиница, цифры и _"
				} }));
				return false;
			}
			if (get().contacts.some((c) => c.username === normalizeUsername(authUsername)) || normalizeUsername(authUsername) === "telechat") {
				set((s) => ({ ui: {
					...s.ui,
					authError: "Этот юзернейм уже занят"
				} }));
				return false;
			}
			const contacts = seedContacts();
			const { chats, messages } = seedChatsAndMessages(contacts);
			hydrateSeedMedia(messages);
			const profile = defaultProfile(get().ui.authEmail.trim(), authName.trim(), normalizeUsername(authUsername));
			set({
				profile,
				session: {
					email: profile.email,
					verifiedAt: Date.now(),
					onboarded: true,
					locked: false
				},
				contacts,
				chats,
				messages,
				devices: seedDevices(),
				drafts: {},
				blockedIds: [],
				authStep: "welcome"
			});
			persistSoon();
			return true;
		},
		finishWelcome() {
			set((s) => ({
				authStep: "app",
				session: s.session ? {
					...s.session,
					onboarded: true
				} : s.session
			}));
			persistSoon();
		},
		logout() {
			replyTimers.forEach(clearTimeout);
			replyTimers = [];
			clearPersisted();
			applyTheme("dark");
			set({
				session: null,
				profile: null,
				contacts: [],
				chats: [],
				messages: {},
				devices: [],
				drafts: {},
				blockedIds: [],
				wallpaper: "ink",
				theme: "dark",
				authStep: "email",
				ui: emptyUi()
			});
		},
		openChat(chatId) {
			set((s) => ({ ui: {
				...s.ui,
				activeChatId: chatId,
				selectedMessageId: null,
				chatInfoOpen: false,
				showArchived: chatId ? s.ui.showArchived : s.ui.showArchived
			} }));
			if (chatId) get().markRead(chatId);
		},
		setChatFilter(filter) {
			set((s) => ({ ui: {
				...s.ui,
				chatFilter: filter
			} }));
		},
		setShowArchived(value) {
			set((s) => ({ ui: {
				...s.ui,
				showArchived: value,
				activeChatId: null
			} }));
		},
		setSearchQuery(value) {
			set((s) => ({ ui: {
				...s.ui,
				searchQuery: value
			} }));
		},
		setContactQuery(value) {
			set((s) => ({ ui: {
				...s.ui,
				contactQuery: value
			} }));
		},
		setComingSoon(feature) {
			set((s) => ({ ui: {
				...s.ui,
				comingSoon: feature
			} }));
		},
		setCreateMode(mode) {
			set((s) => ({ ui: {
				...s.ui,
				createMode: mode
			} }));
		},
		setChatInfoOpen(open) {
			set((s) => ({ ui: {
				...s.ui,
				chatInfoOpen: open
			} }));
		},
		setDraft(chatId, text, replyToId) {
			set((s) => ({ drafts: {
				...s.drafts,
				[chatId]: {
					chatId,
					text,
					replyToId,
					updatedAt: Date.now()
				}
			} }));
			persistSoon();
		},
		setReply(chatId, messageId) {
			const current = get().drafts[chatId];
			get().setDraft(chatId, current?.text ?? "", messageId);
		},
		sendText(chatId, text) {
			const clean = text.trim();
			if (!clean) return;
			const chat = get().chats.find((c) => c.id === chatId);
			if (!chat || get().blockedIds.some((id) => chat.participantIds.includes(id) && chat.type === "direct")) return;
			appendMessage(makeMessage({
				chatId,
				senderId: ME_ID,
				text: clean
			}));
			get().setDraft(chatId, "", null);
			scheduleReply(chatId, clean);
		},
		sendVoice(chatId, mediaId, durationMs, peaks) {
			appendMessage(makeMessage({
				chatId,
				senderId: ME_ID,
				type: "voice",
				voice: {
					mediaId,
					durationMs,
					peaks
				}
			}));
			scheduleReply(chatId, "голос");
		},
		sendPhoto(chatId, mediaId, width, height, caption) {
			appendMessage(makeMessage({
				chatId,
				senderId: ME_ID,
				type: "photo",
				text: caption ?? "",
				photo: {
					mediaId,
					width,
					height,
					caption
				}
			}));
			scheduleReply(chatId, caption || "фото");
		},
		sendVideo(chatId, mediaId, durationMs, width, height, caption) {
			appendMessage(makeMessage({
				chatId,
				senderId: ME_ID,
				type: "video",
				text: caption ?? "",
				video: {
					mediaId,
					durationMs,
					width,
					height,
					caption
				}
			}));
			scheduleReply(chatId, caption || "видео");
		},
		toggleReaction(chatId, messageId, reaction) {
			set((state) => ({ messages: {
				...state.messages,
				[chatId]: (state.messages[chatId] ?? []).map((m) => {
					if (m.id !== messageId) return m;
					const current = new Set(m.reactions[reaction] ?? []);
					if (current.has("user_me")) current.delete(ME_ID);
					else current.add(ME_ID);
					return {
						...m,
						reactions: {
							...m.reactions,
							[reaction]: Array.from(current)
						}
					};
				})
			} }));
			persistSoon();
		},
		deleteMessage(chatId, messageId, forAll) {
			set((state) => ({ messages: {
				...state.messages,
				[chatId]: (state.messages[chatId] ?? []).map((m) => {
					if (m.id !== messageId) return m;
					if (forAll) return {
						...m,
						deletedForAll: true,
						text: "",
						voice: void 0,
						photo: void 0,
						video: void 0
					};
					return {
						...m,
						deletedForMe: true
					};
				})
			} }));
			const last = [...(get().messages[chatId] ?? []).filter((m) => !m.deletedForMe)].reverse().find((m) => !m.deletedForAll);
			bumpChat(chatId, last ? previewFrom(last) : "", last?.createdAt ?? Date.now());
			persistSoon();
		},
		setForwardMessage(messageId) {
			set((s) => ({ ui: {
				...s.ui,
				forwardMessageId: messageId
			} }));
		},
		forwardMessage(messageId, toChatId) {
			let found;
			for (const list of Object.values(get().messages)) {
				found = list.find((m) => m.id === messageId);
				if (found) break;
			}
			if (!found || found.deletedForAll) return;
			const from = found.senderId === "user_me" ? get().profile : get().contacts.find((c) => c.id === found?.senderId);
			appendMessage(makeMessage({
				chatId: toChatId,
				senderId: ME_ID,
				type: found.type,
				text: found.text,
				voice: found.voice,
				photo: found.photo,
				video: found.video,
				forwarded: {
					fromId: found.senderId,
					fromName: from?.displayName ?? "TeleChat"
				}
			}));
			set((s) => ({ ui: {
				...s.ui,
				forwardMessageId: null
			} }));
			scheduleReply(toChatId, found.text || "сообщение");
		},
		async copyMessage(messageId) {
			let found;
			for (const list of Object.values(get().messages)) {
				found = list.find((m) => m.id === messageId);
				if (found) break;
			}
			if (!found?.text) return;
			try {
				await navigator.clipboard.writeText(found.text);
			} catch {}
		},
		createDirectChat(contactId) {
			const existing = get().chats.find((c) => c.type === "direct" && c.participantIds.includes(contactId) && !c.deletedForMe);
			if (existing) {
				get().openChat(existing.id);
				set((s) => ({ ui: {
					...s.ui,
					tab: "chats",
					createMode: null
				} }));
				return existing.id;
			}
			const contact = get().contacts.find((c) => c.id === contactId);
			if (!contact) return "";
			const chat = {
				id: createId("chat"),
				type: "direct",
				title: contact.displayName,
				avatar: contact.avatar,
				participantIds: [ME_ID, contactId],
				lastMessagePreview: "",
				lastMessageAt: Date.now(),
				unread: 0,
				muted: false,
				archived: false,
				pinned: false,
				pinnedMessageId: null,
				createdAt: Date.now(),
				createdBy: ME_ID,
				deletedForMe: false
			};
			set((s) => ({
				chats: [chat, ...s.chats],
				messages: {
					...s.messages,
					[chat.id]: []
				},
				ui: {
					...s.ui,
					tab: "chats",
					activeChatId: chat.id,
					createMode: null
				}
			}));
			persistSoon();
			return chat.id;
		},
		createGroup(title, memberIds, avatar) {
			const name = title.trim();
			if (!name) return "";
			const chat = {
				id: createId("grp"),
				type: "group",
				title: name,
				avatar: avatar ?? {
					kind: "gradient",
					hue: name.length * 17,
					initials: name.slice(0, 2).toUpperCase()
				},
				participantIds: [ME_ID, ...memberIds.filter((id) => id !== ME_ID)],
				lastMessagePreview: "Группа создана",
				lastMessageAt: Date.now(),
				unread: 0,
				muted: false,
				archived: false,
				pinned: false,
				pinnedMessageId: null,
				createdAt: Date.now(),
				createdBy: ME_ID,
				deletedForMe: false
			};
			const system = makeMessage({
				chatId: chat.id,
				senderId: ME_ID,
				type: "system",
				text: `Вы создали группу «${name}»`
			});
			set((s) => ({
				chats: [chat, ...s.chats],
				messages: {
					...s.messages,
					[chat.id]: [system]
				},
				ui: {
					...s.ui,
					tab: "chats",
					activeChatId: chat.id,
					createMode: null
				}
			}));
			persistSoon();
			return chat.id;
		},
		archiveChat(chatId, archived) {
			set((s) => ({
				chats: s.chats.map((c) => c.id === chatId ? {
					...c,
					archived
				} : c),
				ui: {
					...s.ui,
					activeChatId: s.ui.activeChatId === chatId ? null : s.ui.activeChatId
				}
			}));
			persistSoon();
		},
		muteChat(chatId, muted) {
			set((s) => ({ chats: s.chats.map((c) => c.id === chatId ? {
				...c,
				muted
			} : c) }));
			persistSoon();
		},
		pinChat(chatId, pinned) {
			set((s) => ({ chats: s.chats.map((c) => c.id === chatId ? {
				...c,
				pinned
			} : c) }));
			persistSoon();
		},
		deleteChat(chatId, forAll) {
			if (forAll) set((s) => ({
				chats: s.chats.filter((c) => c.id !== chatId),
				messages: Object.fromEntries(Object.entries(s.messages).filter(([id]) => id !== chatId)),
				ui: {
					...s.ui,
					activeChatId: s.ui.activeChatId === chatId ? null : s.ui.activeChatId
				}
			}));
			else set((s) => ({
				chats: s.chats.map((c) => c.id === chatId ? {
					...c,
					deletedForMe: true,
					unread: 0
				} : c),
				ui: {
					...s.ui,
					activeChatId: s.ui.activeChatId === chatId ? null : s.ui.activeChatId
				}
			}));
			persistSoon();
		},
		markRead(chatId) {
			set((s) => ({
				chats: s.chats.map((c) => c.id === chatId ? {
					...c,
					unread: 0
				} : c),
				messages: {
					...s.messages,
					[chatId]: (s.messages[chatId] ?? []).map((m) => m.senderId !== "user_me" ? {
						...m,
						status: "read"
					} : m)
				}
			}));
			persistSoon();
		},
		updateProfile(patch) {
			set((s) => ({ profile: s.profile ? {
				...s.profile,
				...patch
			} : s.profile }));
			persistSoon();
		},
		setAvatar(avatar) {
			get().updateProfile({ avatar });
		},
		setAnimalAvatar(animal) {
			get().updateProfile({ avatar: {
				kind: "animal",
				animal
			} });
		},
		setPin(pin) {
			get().updateProfile({ pin });
		},
		lock() {
			if (!get().profile?.pin) return;
			set((s) => ({
				session: s.session ? {
					...s.session,
					locked: true
				} : s.session,
				ui: {
					...s.ui,
					pinInput: "",
					pinError: null
				}
			}));
			persistSoon();
		},
		unlock(pin) {
			if (pin !== get().profile?.pin) {
				set((s) => ({ ui: {
					...s.ui,
					pinError: "Неверный код"
				} }));
				return false;
			}
			set((s) => ({
				session: s.session ? {
					...s.session,
					locked: false
				} : s.session,
				ui: {
					...s.ui,
					pinInput: "",
					pinError: null
				}
			}));
			persistSoon();
			return true;
		},
		setPinInput(value) {
			set((s) => ({ ui: {
				...s.ui,
				pinInput: value.replace(/\D/g, "").slice(0, 6),
				pinError: null
			} }));
		},
		terminateDevice(deviceId) {
			set((s) => ({ devices: s.devices.filter((d) => d.id !== deviceId || d.current) }));
			persistSoon();
		},
		blockContact(contactId, blocked) {
			set((s) => ({
				blockedIds: blocked ? Array.from(/* @__PURE__ */ new Set([...s.blockedIds, contactId])) : s.blockedIds.filter((id) => id !== contactId),
				contacts: s.contacts.map((c) => c.id === contactId ? {
					...c,
					isBlocked: blocked
				} : c)
			}));
			persistSoon();
		},
		addContactByUsername(username) {
			const handle = normalizeUsername(username);
			return get().contacts.find((c) => c.username === handle) ?? null;
		},
		openMedia(chatId, messageId) {
			set((s) => ({ ui: {
				...s.ui,
				mediaViewer: messageId ? {
					chatId,
					messageId
				} : null
			} }));
		},
		tickPresence() {
			set((s) => ({
				contacts: s.contacts.map((c) => {
					if (c.isOfficial) return {
						...c,
						online: true,
						lastSeen: Date.now()
					};
					if (c.typing) return c;
					const wander = Math.sin(Date.now() / 7e4 + c.id.length) > .25;
					return {
						...c,
						online: wander && !c.isBlocked,
						lastSeen: wander ? Date.now() : c.lastSeen
					};
				}),
				devices: s.devices.map((d) => d.current ? {
					...d,
					lastActive: Date.now()
				} : d)
			}));
		}
	};
});
function makeMessage(partial) {
	return {
		id: createId("msg"),
		chatId: partial.chatId,
		senderId: partial.senderId,
		type: partial.type ?? "text",
		text: partial.text ?? "",
		createdAt: Date.now(),
		editedAt: null,
		status: partial.senderId === "user_me" ? "sent" : "delivered",
		replyToId: null,
		forwarded: partial.forwarded ?? null,
		reactions: {},
		deletedForMe: false,
		deletedForAll: false,
		voice: partial.voice,
		photo: partial.photo,
		video: partial.video
	};
}
function selectVisibleChats(state) {
	const q = state.ui.searchQuery.trim().toLowerCase();
	return state.chats.filter((c) => !c.deletedForMe).filter((c) => state.ui.showArchived ? c.archived : !c.archived).filter((c) => {
		if (state.ui.chatFilter === "unread") return c.unread > 0;
		if (state.ui.chatFilter === "groups") return c.type === "group";
		if (state.ui.chatFilter === "muted") return c.muted;
		return true;
	}).filter((c) => {
		if (!q) return true;
		if (c.title.toLowerCase().includes(q)) return true;
		if (c.lastMessagePreview.toLowerCase().includes(q)) return true;
		return c.participantIds.some((id) => {
			const contact = state.contacts.find((x) => x.id === id);
			return contact?.displayName.toLowerCase().includes(q) || contact?.username.toLowerCase().includes(q);
		});
	}).sort((a, b) => {
		if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
		return b.lastMessageAt - a.lastMessageAt;
	});
}
function selectContacts(state) {
	const q = state.ui.contactQuery.trim().toLowerCase().replace(/^@/, "");
	return state.contacts.filter((c) => !c.isBlocked).filter((c) => {
		if (!q) return true;
		return c.displayName.toLowerCase().includes(q) || c.username.toLowerCase().includes(q) || c.bio.toLowerCase().includes(q);
	}).sort((a, b) => Number(b.online) - Number(a.online) || a.displayName.localeCompare(b.displayName, "ru"));
}
function findMessage(state, messageId) {
	if (!messageId) return void 0;
	for (const list of Object.values(state.messages)) {
		const found = list.find((m) => m.id === messageId);
		if (found) return found;
	}
}
function chatPeer(state, chat) {
	if (chat.type === "group") return void 0;
	const id = chat.participantIds.find((x) => x !== ME_ID);
	if (id === "user_me") return state.profile ?? void 0;
	return state.contacts.find((c) => c.id === id);
}
function AuthFlow() {
	const step = useTelechat((s) => s.authStep);
	if (step === "welcome") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WelcomeScreen, {});
	if (step === "code") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeScreen, {});
	if (step === "username") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsernameScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmailScreen, {});
}
function Shell({ children, onBack, step }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "app-wallpaper-ink flex min-h-dvh flex-col px-5 pb-8 pt-[max(1.5rem,env(safe-area-inset-top))]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-md flex-1 flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [
						onBack ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onBack,
							className: "tap flex size-11 items-center justify-center rounded-2xl bg-surface text-fg",
							"aria-label": "Назад",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-11" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TelechatMark, { className: "size-10" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-11" })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 flex gap-1.5",
					children: [
						0,
						1,
						2
					].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("h-1 flex-1 rounded-full transition-colors duration-200", i <= step ? "bg-accent" : "bg-surface-2") }, i))
				}),
				children
			]
		})
	});
}
function EmailScreen() {
	const email = useTelechat((s) => s.ui.authEmail);
	const error = useTelechat((s) => s.ui.authError);
	const setAuthEmail = useTelechat((s) => s.setAuthEmail);
	const requestCode = useTelechat((s) => s.requestCode);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		step: 0,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "rise-in mt-10 text-[32px] font-semibold leading-tight tracking-tight",
				children: t.emailTitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rise-in rise-in-1 mt-3 text-sm leading-relaxed text-muted",
				children: t.emailHint
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "rise-in rise-in-2 mt-8 block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mb-2 flex items-center gap-2 text-xs font-medium text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "size-3.5" }), " Почта"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					autoFocus: true,
					type: "email",
					inputMode: "email",
					autoComplete: "email",
					value: email,
					onChange: (e) => setAuthEmail(e.target.value),
					onKeyDown: (e) => {
						if (e.key === "Enter") requestCode();
					},
					placeholder: t.emailPlaceholder,
					className: "h-12 w-full rounded-2xl border border-border bg-surface px-4 text-[16px] outline-none ring-accent transition-[box-shadow] focus:ring-2"
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => requestCode(),
				className: "tap rise-in rise-in-3 mt-auto h-12 rounded-2xl bg-accent text-[15px] font-semibold text-accent-fg",
				children: t.continue
			})
		]
	});
}
function CodeScreen() {
	const email = useTelechat((s) => s.ui.authEmail);
	const code = useTelechat((s) => s.ui.authCode);
	const error = useTelechat((s) => s.ui.authError);
	const setAuthCode = useTelechat((s) => s.setAuthCode);
	const verifyCode = useTelechat((s) => s.verifyCode);
	const hiddenRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		hiddenRef.current?.focus();
	}, []);
	(0, import_react.useEffect)(() => {
		if (code.length === 4) verifyCode();
	}, [code, verifyCode]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		step: 1,
		onBack: () => useTelechat.setState({ authStep: "email" }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "rise-in mt-10 text-[32px] font-semibold leading-tight tracking-tight",
				children: t.codeTitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rise-in rise-in-1 mt-3 text-sm leading-relaxed text-muted",
				children: [
					t.codeHint,
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-fg",
						children: email
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: hiddenRef,
				inputMode: "numeric",
				autoComplete: "one-time-code",
				value: code,
				onChange: (e) => setAuthCode(e.target.value),
				className: "sr-only",
				"aria-label": "Код подтверждения"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => hiddenRef.current?.focus(),
				className: "rise-in rise-in-2 mt-10 flex justify-center gap-2",
				children: Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("flex size-14 items-center justify-center rounded-2xl border bg-surface text-2xl font-semibold tabular-nums", code.length === i ? "border-accent ring-2 ring-accent/40" : "border-border"),
					children: code[i] ?? ""
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-center text-sm text-muted",
				children: t.codeDemo
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-center text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => verifyCode(),
				className: "tap mt-auto h-12 rounded-2xl bg-accent text-[15px] font-semibold text-accent-fg",
				children: t.continue
			})
		]
	});
}
function UsernameScreen() {
	const name = useTelechat((s) => s.ui.authName);
	const username = useTelechat((s) => s.ui.authUsername);
	const error = useTelechat((s) => s.ui.authError);
	const setAuthName = useTelechat((s) => s.setAuthName);
	const setAuthUsername = useTelechat((s) => s.setAuthUsername);
	const completeProfile = useTelechat((s) => s.completeProfile);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		step: 2,
		onBack: () => useTelechat.setState({ authStep: "code" }),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "rise-in mt-10 text-[32px] font-semibold leading-tight tracking-tight",
				children: t.usernameTitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rise-in rise-in-1 mt-3 text-sm leading-relaxed text-muted",
				children: t.usernameHint
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "rise-in rise-in-2 mt-8 block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mb-2 block text-xs font-medium text-muted",
					children: t.namePlaceholder
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					autoFocus: true,
					value: name,
					onChange: (e) => setAuthName(e.target.value),
					placeholder: "Анна",
					className: "h-12 w-full rounded-2xl border border-border bg-surface px-4 text-[16px] outline-none ring-accent focus:ring-2"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mb-2 block text-xs font-medium text-muted",
					children: "Юзернейм"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-12 items-center rounded-2xl border border-border bg-surface px-4 ring-accent focus-within:ring-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: "@"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: username,
						onChange: (e) => setAuthUsername(e.target.value),
						placeholder: "username",
						className: "h-full w-full bg-transparent pl-1 text-[16px] outline-none"
					})]
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => completeProfile(),
				className: "tap mt-auto h-12 rounded-2xl bg-accent text-[15px] font-semibold text-accent-fg",
				children: t.start
			})
		]
	});
}
function WelcomeScreen() {
	const name = useTelechat((s) => s.profile?.displayName ?? "");
	const finishWelcome = useTelechat((s) => s.finishWelcome);
	(0, import_react.useEffect)(() => {
		const timer = setTimeout(() => finishWelcome(), 1800);
		return () => clearTimeout(timer);
	}, [finishWelcome]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-wallpaper-ink flex min-h-dvh flex-col items-center justify-center px-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TelechatMark, { className: "rise-in size-16" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "rise-in rise-in-2 mt-8 text-[34px] font-semibold tracking-tight",
				children: t.welcome
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "rise-in rise-in-3 mt-3 max-w-sm text-sm leading-relaxed text-muted",
				children: [name ? `${name}, всё готово.` : t.welcomeSub, " Можно писать, записывать голос и делиться кадрами."]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: finishWelcome,
				className: "tap rise-in rise-in-4 mt-10 h-12 rounded-2xl bg-accent px-8 text-[15px] font-semibold text-accent-fg",
				children: "Перейти к чатам"
			})
		]
	});
}
function Splash() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-wallpaper-ink flex min-h-dvh flex-col items-center justify-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TelechatMark, { className: "size-16" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-5 text-lg font-semibold tracking-tight",
			children: "TeleChat"
		})]
	});
}
function PinLock() {
	const pinInput = useTelechat((s) => s.ui.pinInput);
	const error = useTelechat((s) => s.ui.pinError);
	const setPinInput = useTelechat((s) => s.setPinInput);
	const unlock = useTelechat((s) => s.unlock);
	const hiddenRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		hiddenRef.current?.focus();
	}, []);
	(0, import_react.useEffect)(() => {
		if (pinInput.length === 6) unlock(pinInput);
	}, [pinInput, unlock]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-wallpaper-ink flex min-h-dvh flex-col items-center px-6 pt-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TelechatMark, { className: "size-14" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-8 text-2xl font-semibold tracking-tight",
				children: t.enterPin
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: hiddenRef,
				inputMode: "numeric",
				value: pinInput,
				onChange: (e) => setPinInput(e.target.value),
				className: "sr-only",
				"aria-label": "Код-пароль"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => hiddenRef.current?.focus(),
				className: "mt-8 flex gap-2.5",
				children: Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-3.5 rounded-full border", i < pinInput.length ? "border-accent bg-accent" : "border-border-strong") }, i))
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-danger",
				children: error
			}) : null
		]
	});
}
var TABS = [
	{
		id: "chats",
		label: t.chats,
		icon: MessageCircle
	},
	{
		id: "contacts",
		label: t.contacts,
		icon: Users
	},
	{
		id: "settings",
		label: t.settings,
		icon: Settings
	},
	{
		id: "profile",
		label: t.profile,
		icon: UserRound
	}
];
function BottomNav() {
	const tab = useTelechat((s) => s.ui.tab);
	const setTab = useTelechat((s) => s.setTab);
	const unread = useTelechat((s) => s.chats.reduce((sum, c) => sum + (c.archived || c.deletedForMe ? 0 : c.unread), 0));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "grid grid-cols-4 border-t border-border bg-bg-elevated/95 px-1 pb-[max(0.4rem,env(safe-area-inset-bottom))] pt-1 backdrop-blur-md",
		children: TABS.map((item) => {
			const active = tab === item.id;
			const Icon = item.icon;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => {
					setTab(item.id);
					useTelechat.getState().openChat(null);
				},
				className: cn("tap relative flex min-h-12 flex-col items-center justify-center gap-0.5 rounded-2xl text-[11px] font-medium", active ? "text-accent" : "text-muted"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "relative",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
						className: "size-5",
						strokeWidth: active ? 2.4 : 1.8
					}), item.id === "chats" && unread > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "absolute -top-1.5 -right-2.5 min-w-4 rounded-full bg-accent px-1 text-[9px] font-semibold text-accent-fg",
						children: unread > 99 ? "99+" : unread
					}) : null]
				}), item.label]
			}, item.id);
		})
	});
}
var FACE = {
	fox: {
		bg: "#c56a32",
		draw: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 22 L16 8 L24 22 Z",
				fill: "#e3894a"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M10 12 L16 22 L22 12",
				fill: "#f3d2b0"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "13.2",
				cy: "16.5",
				r: "1.1",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "18.8",
				cy: "16.5",
				r: "1.1",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M15.2 19.4h1.6l.6 1.4h-2.8z",
				fill: "#1b140f"
			})
		] })
	},
	cat: {
		bg: "#d8a35a",
		draw: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "18",
				rx: "8",
				ry: "7",
				fill: "#f0c27a"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 16 L10 7 L14 14 Z",
				fill: "#f0c27a"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M24 16 L22 7 L18 14 Z",
				fill: "#f0c27a"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "13",
				cy: "17.5",
				r: "1.15",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "19",
				cy: "17.5",
				r: "1.15",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M16 20.2c1.4 0 2.2.8 2.2.8",
				stroke: "#1b140f",
				strokeWidth: "1",
				fill: "none",
				strokeLinecap: "round"
			})
		] })
	},
	owl: {
		bg: "#3d4c63",
		draw: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "18",
				rx: "8.5",
				ry: "8",
				fill: "#6d7f98"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12.4",
				cy: "16.6",
				r: "3.4",
				fill: "#f4efe4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "19.6",
				cy: "16.6",
				r: "3.4",
				fill: "#f4efe4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12.4",
				cy: "16.8",
				r: "1.4",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "19.6",
				cy: "16.8",
				r: "1.4",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M16 20 l2 3 h-4z",
				fill: "#e2a15a"
			})
		] })
	},
	bear: {
		bg: "#7a4c2e",
		draw: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "10",
				cy: "11",
				r: "3.2",
				fill: "#8b5a38"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "22",
				cy: "11",
				r: "3.2",
				fill: "#8b5a38"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "18",
				rx: "8.5",
				ry: "7.5",
				fill: "#a36a42"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "20",
				rx: "4.2",
				ry: "3.2",
				fill: "#e8c9a8"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "13.1",
				cy: "16.4",
				r: "1.15",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "18.9",
				cy: "16.4",
				r: "1.15",
				fill: "#1b140f"
			})
		] })
	},
	panda: {
		bg: "#ececec",
		draw: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "18",
				rx: "8.2",
				ry: "7.6",
				fill: "#f7f7f7"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "10.2",
				cy: "11.4",
				r: "3",
				fill: "#1c1c1c"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "21.8",
				cy: "11.4",
				r: "3",
				fill: "#1c1c1c"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "12.4",
				cy: "16.8",
				rx: "2.6",
				ry: "2.3",
				fill: "#1c1c1c"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "19.6",
				cy: "16.8",
				rx: "2.6",
				ry: "2.3",
				fill: "#1c1c1c"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12.6",
				cy: "16.8",
				r: "0.85",
				fill: "#f7f7f7"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "19.8",
				cy: "16.8",
				r: "0.85",
				fill: "#f7f7f7"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "20.6",
				rx: "1.4",
				ry: "1",
				fill: "#1c1c1c"
			})
		] })
	},
	wolf: {
		bg: "#6d7786",
		draw: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M7 22 L16 7 L25 22 Z",
				fill: "#8b96a6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M12 16 L16 22 L20 16",
				fill: "#d5dbe4"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "13.4",
				cy: "16.2",
				r: "1.05",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "18.6",
				cy: "16.2",
				r: "1.05",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M16 18.6l1.3 2.1h-2.6z",
				fill: "#1b140f"
			})
		] })
	},
	rabbit: {
		bg: "#e7c3c9",
		draw: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "12",
				cy: "9",
				rx: "2.2",
				ry: "6.4",
				fill: "#f3d4d9"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "20",
				cy: "9",
				rx: "2.2",
				ry: "6.4",
				fill: "#f3d4d9"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "19",
				rx: "7.4",
				ry: "6.6",
				fill: "#f7dde1"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "13.3",
				cy: "18.4",
				r: "1.05",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "18.7",
				cy: "18.4",
				r: "1.05",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "21.4",
				rx: "1.2",
				ry: "0.9",
				fill: "#d98996"
			})
		] })
	},
	whale: {
		bg: "#3a6d8c",
		draw: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "15",
				cy: "17.5",
				rx: "9",
				ry: "6.2",
				fill: "#5a97b8"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M23 17 l6 -4 v8z",
				fill: "#5a97b8"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "11.5",
				cy: "16.4",
				r: "1.15",
				fill: "#0e1b24"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "11.9",
				cy: "16.1",
				r: "0.35",
				fill: "#f4f7fa"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 18.6c1.6 1.4 3.6 1.4 5.2 0",
				stroke: "#0e1b24",
				strokeWidth: "1",
				fill: "none"
			})
		] })
	},
	bird: {
		bg: "#e0b84a",
		draw: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "18",
				rx: "8",
				ry: "6.5",
				fill: "#f0c85c"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "21",
				cy: "13",
				r: "4.4",
				fill: "#f0c85c"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "22.2",
				cy: "12.4",
				r: "1.05",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M24.8 13.4l4 .8-4 1.6z",
				fill: "#e07a32"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 18 l6 2 -6 2z",
				fill: "#d9a32c"
			})
		] })
	},
	tiger: {
		bg: "#d98332",
		draw: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "18",
				rx: "8.4",
				ry: "7.4",
				fill: "#e79a44"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 12 l3-5 3 6",
				fill: "#e79a44"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M24 12 l-3-5 -3 6",
				fill: "#e79a44"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M12 13 v8 M16 12 v10 M20 13 v8",
				stroke: "#1b140f",
				strokeWidth: "1.3"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "13",
				cy: "17.5",
				r: "1.1",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "19",
				cy: "17.5",
				r: "1.1",
				fill: "#1b140f"
			})
		] })
	},
	frog: {
		bg: "#5ea35a",
		draw: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "19",
				rx: "9",
				ry: "6.5",
				fill: "#7bc16f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "11.5",
				cy: "14",
				r: "3.3",
				fill: "#7bc16f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "20.5",
				cy: "14",
				r: "3.3",
				fill: "#7bc16f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "11.5",
				cy: "14",
				r: "1.4",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "20.5",
				cy: "14",
				r: "1.4",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "21.2",
				rx: "2.4",
				ry: "1.2",
				fill: "#2a4a28"
			})
		] })
	},
	dog: {
		bg: "#c48a4a",
		draw: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "18.5",
				rx: "8",
				ry: "7",
				fill: "#d9a05c"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "8.6",
				cy: "16",
				rx: "2.4",
				ry: "3.6",
				fill: "#b4783c"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "23.4",
				cy: "16",
				rx: "2.4",
				ry: "3.6",
				fill: "#b4783c"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "21",
				rx: "3.4",
				ry: "2.4",
				fill: "#f0d3ae"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "13.2",
				cy: "17.2",
				r: "1.1",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "18.8",
				cy: "17.2",
				r: "1.1",
				fill: "#1b140f"
			})
		] })
	},
	deer: {
		bg: "#b07848",
		draw: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M10 10 l-2-6 M10 10 l2-5 M22 10 l2-6 M22 10 l-2-5",
				stroke: "#d9b08a",
				strokeWidth: "1.4",
				fill: "none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "18.4",
				rx: "7.6",
				ry: "7",
				fill: "#c48a58"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "13.3",
				cy: "17.4",
				r: "1.05",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "18.7",
				cy: "17.4",
				r: "1.05",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "21.2",
				rx: "1.5",
				ry: "1.1",
				fill: "#1b140f"
			})
		] })
	},
	penguin: {
		bg: "#2c3644",
		draw: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "18",
				rx: "8",
				ry: "8.4",
				fill: "#3b4656"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "20",
				rx: "5.4",
				ry: "6",
				fill: "#f4efe6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "13.2",
				cy: "15.2",
				r: "1.05",
				fill: "#0e1116"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "18.8",
				cy: "15.2",
				r: "1.05",
				fill: "#0e1116"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M16 16.4l2.2 1.4h-4.4z",
				fill: "#e28a3a"
			})
		] })
	},
	koala: {
		bg: "#9aa3ad",
		draw: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "8.5",
				cy: "13.5",
				r: "4.4",
				fill: "#b7c0c9"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "23.5",
				cy: "13.5",
				r: "4.4",
				fill: "#b7c0c9"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "18.5",
				rx: "8",
				ry: "7.2",
				fill: "#c5ced6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "20.6",
				rx: "3.2",
				ry: "2.4",
				fill: "#e7edf2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "13.2",
				cy: "17.2",
				r: "1.1",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "18.8",
				cy: "17.2",
				r: "1.1",
				fill: "#1b140f"
			})
		] })
	},
	otter: {
		bg: "#8a5a3c",
		draw: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "17.8",
				rx: "8.4",
				ry: "7.2",
				fill: "#a66c48"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "16",
				cy: "20.4",
				rx: "4",
				ry: "2.8",
				fill: "#e8c7a6"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12.8",
				cy: "16.6",
				r: "1.1",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "19.2",
				cy: "16.6",
				r: "1.1",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 22c3 3 13 3 16 0",
				stroke: "#a66c48",
				strokeWidth: "3",
				fill: "none"
			})
		] })
	}
};
function AnimalFace({ animal }) {
	const spec = FACE[animal];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-full",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "32",
			height: "32",
			rx: "16",
			fill: spec.bg
		}), spec.draw]
	});
}
function UserAvatar({ avatar, size = "md", online, className }) {
	const dim = size === "sm" ? "size-9 text-[12px]" : size === "lg" ? "size-16 text-[22px]" : size === "xl" ? "size-24 text-[28px]" : "size-12 text-[15px]";
	const dot = size === "sm" ? "size-2" : size === "xl" ? "size-3.5" : "size-2.5";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative shrink-0", dim, className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "size-full overflow-hidden rounded-full ring-1 ring-border",
			children: avatar.kind === "image" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: avatar.src,
				alt: "",
				className: "size-full object-cover"
			}) : avatar.kind === "animal" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimalFace, { animal: avatar.animal }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex size-full items-center justify-center font-semibold text-white",
				style: { background: `linear-gradient(145deg, hsl(${avatar.hue} 42% 46%), hsl(${(avatar.hue + 28) % 360} 38% 28%))` },
				children: avatar.initials
			})
		}), online ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute right-0 bottom-0 rounded-full bg-success ring-2 ring-bg", dot) }) : null]
	});
}
var MONTHS_SHORT = [
	"янв",
	"фев",
	"мар",
	"апр",
	"мая",
	"июн",
	"июл",
	"авг",
	"сен",
	"окт",
	"ноя",
	"дек"
];
function startOfDay(ts) {
	const d = new Date(ts);
	d.setHours(0, 0, 0, 0);
	return d.getTime();
}
function pad2(n) {
	return n.toString().padStart(2, "0");
}
function formatTime(ts) {
	const d = new Date(ts);
	return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}
function formatChatTime(ts, now = Date.now()) {
	const day = startOfDay(ts);
	const diff = startOfDay(now) - day;
	if (diff === 0) return formatTime(ts);
	if (diff === 864e5) return t.yesterday;
	const d = new Date(ts);
	if (d.getFullYear() === new Date(now).getFullYear()) return `${d.getDate()} ${MONTHS_SHORT[d.getMonth()]}`;
	return `${pad2(d.getDate())}.${pad2(d.getMonth() + 1)}.${d.getFullYear()}`;
}
function formatLastSeen(ts, now = Date.now()) {
	const delta = Math.max(0, now - ts);
	if (delta < 2e4) return t.justNow;
	if (delta < 6e4) return `${Math.floor(delta / 1e3)} с`;
	if (delta < 36e5) return `${Math.floor(delta / 6e4)} мин`;
	if (delta < 792e5) return `${Math.floor(delta / 36e5)} ч`;
	return `${t.lastSeen} ${formatChatTime(ts, now)}`.toLowerCase();
}
function formatDuration(ms) {
	const total = Math.max(0, Math.round(ms / 1e3));
	return `${Math.floor(total / 60)}:${pad2(total % 60)}`;
}
function formatMembers(count) {
	const mod10 = count % 10;
	const mod100 = count % 100;
	if (mod10 === 1 && mod100 !== 11) return `${count} участник`;
	if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return `${count} участника`;
	return `${count} участников`;
}
function formatUnread(count) {
	if (count > 99) return "99+";
	return String(count);
}
function withAt(username) {
	return `@${username.replace(/^@/, "")}`;
}
function ChatInfo({ chatId, onClose }) {
	const chat = useTelechat((s) => s.chats.find((c) => c.id === chatId));
	const peer = useTelechat((s) => chat ? chatPeer(s, chat) : void 0);
	const members = useTelechat((s) => (chat?.participantIds ?? []).filter((id) => id !== ME_ID).map((id) => s.contacts.find((c) => c.id === id)).filter(Boolean));
	const media = useTelechat((s) => (s.messages[chatId] ?? []).filter((m) => (m.type === "photo" || m.type === "video") && !m.deletedForAll && !m.deletedForMe));
	if (!chat) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "absolute inset-0 z-30 flex flex-col bg-bg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "flex items-center justify-between px-2 pt-[max(0.6rem,env(safe-area-inset-top))]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "tap flex size-11 items-center justify-center rounded-2xl",
					"aria-label": "Закрыть",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-semibold",
					children: "Информация"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-11" })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-0 flex-1 overflow-y-auto px-4 pb-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-col items-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
							avatar: chat.avatar,
							size: "xl"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-3 text-xl font-semibold tracking-tight",
							children: chat.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: chat.type === "group" ? formatMembers(chat.participantIds.length) : peer && "username" in peer ? withAt(peer.username) : ""
						}),
						peer && "bio" in peer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-sm text-center text-sm text-muted",
							children: peer.bio
						}) : null,
						peer && "lastSeen" in peer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-subtle",
							children: peer.online ? "в сети" : formatLastSeen(peer.lastSeen)
						}) : null
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => useTelechat.getState().muteChat(chatId, !chat.muted),
						className: "tap flex h-12 items-center justify-center gap-2 rounded-2xl bg-surface text-sm font-medium",
						children: [chat.muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BellOff, { className: "size-4" }), chat.muted ? "Звук" : "Без звука"]
					}), chat.type === "direct" && peer && "id" in peer ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => useTelechat.getState().blockContact(peer.id, !peer.isBlocked),
						className: "tap flex h-12 items-center justify-center gap-2 rounded-2xl bg-surface text-sm font-medium text-danger",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldBan, { className: "size-4" }), peer.isBlocked ? "Разблок." : "Блок"]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => useTelechat.getState().deleteChat(chatId, false),
						className: "tap flex h-12 items-center justify-center gap-2 rounded-2xl bg-surface text-sm font-medium text-danger",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Удалить"]
					})]
				}),
				chat.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 rounded-2xl bg-surface px-4 py-3 text-sm leading-relaxed",
					children: chat.description
				}) : null,
				chat.type === "group" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-medium text-muted",
						children: "Участники"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden rounded-3xl bg-surface",
						children: members.map((m) => m ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => useTelechat.getState().createDirectChat(m.id),
							className: "tap flex w-full items-center gap-3 px-3 py-2.5 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
								avatar: m.avatar,
								size: "sm",
								online: m.online
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block truncate font-medium",
									children: m.displayName
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted",
									children: ["@", m.username]
								})]
							})]
						}, m.id) : null)
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs font-medium text-muted",
						children: "Медиа"
					}), media.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-2xl bg-surface px-4 py-8 text-center text-sm text-muted",
						children: "В этом чате ещё нет медиа"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-3 gap-1",
						children: media.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => useTelechat.getState().openMedia(chatId, m.id),
							className: cn("aspect-square overflow-hidden rounded-xl bg-surface-2"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-full items-center justify-center text-xs text-muted",
								children: m.type === "video" ? "Видео" : "Фото"
							})
						}, m.id))
					})]
				})
			]
		})]
	});
}
function VoicePlayer({ voice, outgoing }) {
	const audioRef = (0, import_react.useRef)(null);
	const [src, setSrc] = (0, import_react.useState)(null);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [progress, setProgress] = (0, import_react.useState)(0);
	const [current, setCurrent] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		let active = true;
		getMedia(voice.mediaId).then((value) => {
			if (active) setSrc(value);
		});
		return () => {
			active = false;
		};
	}, [voice.mediaId]);
	(0, import_react.useEffect)(() => {
		const audio = audioRef.current;
		if (!audio) return;
		const onTime = () => {
			setCurrent(audio.currentTime * 1e3);
			setProgress(audio.duration ? audio.currentTime / audio.duration : 0);
		};
		const onEnd = () => {
			setPlaying(false);
			setProgress(0);
			setCurrent(0);
		};
		audio.addEventListener("timeupdate", onTime);
		audio.addEventListener("ended", onEnd);
		return () => {
			audio.removeEventListener("timeupdate", onTime);
			audio.removeEventListener("ended", onEnd);
		};
	}, [src]);
	const toggle = async () => {
		const audio = audioRef.current;
		if (!audio || !src) return;
		if (playing) {
			audio.pause();
			setPlaying(false);
			return;
		}
		await audio.play();
		setPlaying(true);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-[210px] items-center gap-3",
		children: [
			src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
				ref: audioRef,
				src,
				preload: "metadata"
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => void toggle(),
				className: cn("tap flex size-11 shrink-0 items-center justify-center rounded-full", outgoing ? "bg-white/15 text-white" : "bg-accent text-accent-fg"),
				"aria-label": playing ? "Пауза" : "Слушать",
				children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4 fill-current" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "ml-0.5 size-4 fill-current" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-7 items-end gap-[3px]",
					children: voice.peaks.map((peak, i) => {
						const active = i / voice.peaks.length <= progress;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("w-[3px] rounded-full", active ? outgoing ? "bg-white" : "bg-accent" : outgoing ? "bg-white/35" : "bg-fg/25"),
							style: { height: `${Math.max(18, peak * 100)}%` }
						}, i);
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn("mt-1 text-[11px] tabular-nums", outgoing ? "text-white/70" : "text-muted"),
					children: formatDuration(playing || current > 0 ? current : voice.durationMs)
				})]
			})
		]
	});
}
function RecordingMeter({ peaks, elapsedMs }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 animate-pulse rounded-full bg-danger" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-7 items-end gap-[3px]",
				children: (peaks.length ? peaks : Array.from({ length: 24 }, () => .2)).slice(-24).map((peak, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "wave-bar w-[3px] rounded-full bg-danger/80",
					style: {
						height: `${Math.max(20, peak * 100)}%`,
						animationDelay: `${i * 40}ms`
					}
				}, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm tabular-nums text-danger",
				children: formatDuration(elapsedMs)
			})
		]
	});
}
function Composer({ chatId }) {
	const draft = useTelechat((s) => s.drafts[chatId]);
	const setDraft = useTelechat((s) => s.setDraft);
	const sendText = useTelechat((s) => s.sendText);
	const sendVoice = useTelechat((s) => s.sendVoice);
	const sendPhoto = useTelechat((s) => s.sendPhoto);
	const sendVideo = useTelechat((s) => s.sendVideo);
	const replyTo = useTelechat((s) => {
		const id = s.drafts[chatId]?.replyToId;
		if (!id) return null;
		return (s.messages[chatId] ?? []).find((m) => m.id === id) ?? null;
	});
	const fileRef = (0, import_react.useRef)(null);
	const [recording, setRecording] = (0, import_react.useState)(false);
	const [elapsed, setElapsed] = (0, import_react.useState)(0);
	const recorderRef = (0, import_react.useRef)(null);
	const tickRef = (0, import_react.useRef)(null);
	const text = draft?.text ?? "";
	const canSend = text.trim().length > 0;
	(0, import_react.useEffect)(() => {
		return () => {
			if (tickRef.current) window.clearInterval(tickRef.current);
			recorderRef.current?.cancel();
		};
	}, []);
	const startRec = async () => {
		const rec = createRecorder();
		recorderRef.current = rec;
		try {
			await rec.start();
			setRecording(true);
			const started = Date.now();
			tickRef.current = window.setInterval(() => setElapsed(Date.now() - started), 200);
		} catch {
			setRecording(false);
		}
	};
	const stopRec = async () => {
		if (!recorderRef.current) return;
		if (tickRef.current) window.clearInterval(tickRef.current);
		try {
			const result = await recorderRef.current.stop();
			const stored = await storeVoiceBlob(result.blob, result.durationMs, result.peaks);
			sendVoice(chatId, stored.mediaId, stored.durationMs, stored.peaks);
		} catch {}
		setRecording(false);
		setElapsed(0);
	};
	const onFiles = async (files) => {
		if (!files) return;
		for (const file of Array.from(files)) if (file.type.startsWith("image/")) {
			const stored = await storeImageFile(file);
			sendPhoto(chatId, stored.mediaId, stored.width, stored.height);
		} else if (file.type.startsWith("video/")) {
			const stored = await storeVideoFile(file);
			sendVideo(chatId, stored.mediaId, stored.durationMs, stored.width, stored.height);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-t border-border bg-bg-elevated px-3 pt-2 pb-[max(0.6rem,env(safe-area-inset-bottom))]",
		children: [
			replyTo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center gap-2 rounded-2xl bg-surface px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1 border-l-2 border-accent pl-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-[11px] font-medium text-accent",
						children: "Ответ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "truncate text-xs text-muted",
						children: replyTo.text || "Медиа"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "tap size-8 rounded-full text-muted",
					onClick: () => setDraft(chatId, text, null),
					"aria-label": "Сбросить ответ",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "mx-auto size-4" })
				})]
			}) : null,
			recording ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-2 flex items-center justify-between rounded-2xl bg-surface px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecordingMeter, {
					peaks: [],
					elapsedMs: elapsed
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => void stopRec(),
					className: "tap flex size-11 items-center justify-center rounded-full bg-danger text-white",
					"aria-label": "Остановить запись",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-4 fill-current" })
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => fileRef.current?.click(),
						className: "tap flex size-11 shrink-0 items-center justify-center rounded-2xl bg-surface text-muted",
						"aria-label": t.attach,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Paperclip, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						type: "file",
						accept: "image/*,video/*",
						multiple: true,
						hidden: true,
						onChange: (e) => void onFiles(e.target.files)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 flex-1 items-end rounded-2xl bg-surface px-3 py-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: text,
							rows: 1,
							placeholder: t.messagePlaceholder,
							onChange: (e) => setDraft(chatId, e.target.value, draft?.replyToId ?? null),
							onKeyDown: (e) => {
								if (e.key === "Enter" && !e.shiftKey) {
									e.preventDefault();
									sendText(chatId, text);
								}
							},
							className: "max-h-32 min-h-10 w-full resize-none bg-transparent py-2 text-[15px] outline-none"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => fileRef.current?.click(),
							className: "tap mb-1 flex size-9 items-center justify-center rounded-xl text-muted",
							"aria-label": t.photo,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-5" })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							if (canSend) sendText(chatId, text);
							else startRec();
						},
						className: cn("tap flex size-11 shrink-0 items-center justify-center rounded-2xl", canSend ? "bg-accent text-accent-fg" : "bg-surface text-muted"),
						"aria-label": canSend ? t.send : t.record,
						children: canSend ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-5" })
					})
				]
			})
		]
	});
}
function wrap(children, className) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className: cn("size-4", className),
		"aria-hidden": "true",
		children
	});
}
function ReactionIcon({ id, className }) {
	switch (id) {
		case "heart": return wrap(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M12 20s-7-4.4-9.2-8.4C1 8.4 3.2 5 6.6 5c2 0 3.3 1.1 5.4 3.2C14.1 6.1 15.4 5 17.4 5c3.4 0 5.6 3.4 3.8 6.6C19 15.6 12 20 12 20Z",
			fill: "currentColor"
		}), cn("text-[#e25b73]", className));
		case "like": return wrap(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M8 11v9H5.2A1.2 1.2 0 0 1 4 18.8V12.2A1.2 1.2 0 0 1 5.2 11H8Zm2 9 6.3-0.8c.8-.1 1.5-.7 1.7-1.5l1.2-4.6c.3-1.2-.6-2.3-1.8-2.3H14l.7-3.2c.2-1-.8-1.8-1.8-1.5L9.4 7.6A2 2 0 0 0 8 9.5V20h2Z",
			fill: "currentColor"
		}), cn("text-accent", className));
		case "fire": return wrap(/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M12 3c2 3-1 4.5 1 7 1.4 1.8 4 1.5 4 5.2 0 3.3-2.8 6-7 6s-7-2.7-7-6c0-3.2 2.2-5 3.6-6.6C8.4 6.6 10 5.4 12 3Z",
			fill: "currentColor"
		}), cn("text-[#e8893a]", className));
		case "laugh": return wrap(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "9",
				fill: "currentColor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "9",
				cy: "10",
				r: "1.15",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "15",
				cy: "10",
				r: "1.15",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8 13.5c.8 2.4 7.2 2.4 8 0",
				stroke: "#1b140f",
				strokeWidth: "1.4",
				fill: "none",
				strokeLinecap: "round"
			})
		] }), cn("text-[#e7c04a]", className));
		case "wow": return wrap(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "9",
				fill: "currentColor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "9",
				cy: "10",
				r: "1.2",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "15",
				cy: "10",
				r: "1.2",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ellipse", {
				cx: "12",
				cy: "15.4",
				rx: "1.5",
				ry: "2",
				fill: "#1b140f"
			})
		] }), cn("text-[#7fb3e8]", className));
		case "sad": return wrap(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "12",
				cy: "12",
				r: "9",
				fill: "currentColor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "9",
				cy: "10.2",
				r: "1.15",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "15",
				cy: "10.2",
				r: "1.15",
				fill: "#1b140f"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M8.5 16.4c1.1-1.6 5.9-1.6 7 0",
				stroke: "#1b140f",
				strokeWidth: "1.4",
				fill: "none",
				strokeLinecap: "round"
			})
		] }), cn("text-[#8aa0c2]", className));
	}
}
function MessageBubble({ message, grouped, onLongPress }) {
	const mine = message.senderId === ME_ID;
	const sender = useTelechat((s) => s.contacts.find((c) => c.id === message.senderId));
	const isGroup = useTelechat((s) => s.chats.find((c) => c.id === message.chatId))?.type === "group";
	if (message.deletedForMe) return null;
	if (message.type === "system") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-[80%] rounded-full bg-surface/80 px-3 py-1 text-center text-[11px] text-muted",
		children: message.text
	});
	if (message.deletedForAll) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex", mine ? "justify-end" : "justify-start"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "rounded-2xl bg-surface-2 px-3 py-2 text-sm italic text-muted",
			children: "Сообщение удалено"
		})
	});
	const onContext = (event) => {
		event.preventDefault();
		const point = "touches" in event ? event.touches[0] ?? event.changedTouches[0] : event;
		onLongPress(message, point.clientX, point.clientY);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("flex gap-2", mine ? "justify-end" : "justify-start"),
		children: [!mine && isGroup && !grouped ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
			avatar: sender?.avatar ?? {
				kind: "gradient",
				hue: 200,
				initials: "?"
			},
			size: "sm"
		}) : !mine && isGroup ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-9" }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onContextMenu: onContext,
			onTouchStart: (event) => {
				const timer = window.setTimeout(() => onContext(event), 380);
				const clear = () => window.clearTimeout(timer);
				event.currentTarget.addEventListener("touchend", clear, { once: true });
				event.currentTarget.addEventListener("touchmove", clear, { once: true });
			},
			className: cn("max-w-[82%] rounded-2xl px-3 py-2 text-left shadow-[var(--shadow-bubble)]", mine ? "rounded-br-md bg-outgoing text-white" : "rounded-bl-md bg-incoming text-fg", grouped && mine ? "rounded-tr-md" : null, grouped && !mine ? "rounded-tl-md" : null),
			children: [
				!mine && isGroup && !grouped ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-1 text-[11px] font-medium text-accent",
					children: sender?.displayName
				}) : null,
				message.forwarded ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("mb-1 border-l-2 pl-2 text-[11px]", mine ? "border-white/40 text-white/70" : "border-accent text-muted"),
					children: ["Переслано от ", message.forwarded.fromName]
				}) : null,
				message.type === "voice" && message.voice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VoicePlayer, {
					voice: message.voice,
					outgoing: mine
				}) : null,
				message.type === "photo" && message.photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotoThumb, {
					payload: message.photo,
					onOpen: () => useTelechat.getState().openMedia(message.chatId, message.id)
				}) : null,
				message.type === "video" && message.video ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoThumb, {
					payload: message.video,
					onOpen: () => useTelechat.getState().openMedia(message.chatId, message.id)
				}) : null,
				message.text && message.type !== "voice" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "whitespace-pre-wrap text-[15px] leading-snug",
					children: message.text
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("mt-1 flex items-center justify-end gap-1 text-[10px] tabular-nums", mine ? "text-white/65" : "text-muted"),
					children: [formatTime(message.createdAt), mine ? message.status === "read" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCheck, { className: "size-3.5 text-white/90" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReactionRow, { message })
			]
		})]
	});
}
function ReactionRow({ message }) {
	const entries = Object.entries(message.reactions).filter(([, ids]) => ids.length > 0);
	if (!entries.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-1 flex flex-wrap gap-1",
		children: entries.map(([id, users]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "inline-flex items-center gap-1 rounded-full bg-black/15 px-1.5 py-0.5 text-[10px] font-medium",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReactionIcon, {
				id,
				className: "size-3"
			}), users.length]
		}, id))
	});
}
function PhotoThumb({ payload, onOpen }) {
	const [src, setSrc] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		getMedia(payload.mediaId).then(setSrc);
	}, [payload.mediaId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		role: "button",
		tabIndex: 0,
		onClick: (e) => {
			e.stopPropagation();
			onOpen();
		},
		className: "mb-1 block overflow-hidden rounded-xl",
		children: src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt: payload.caption || "Фото",
			className: "max-h-64 w-full object-cover"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-36 w-56 bg-surface-2" })
	});
}
function VideoThumb({ payload, onOpen }) {
	const [src, setSrc] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		getMedia(payload.mediaId).then(setSrc);
	}, [payload.mediaId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		role: "button",
		tabIndex: 0,
		onClick: (e) => {
			e.stopPropagation();
			onOpen();
		},
		className: "relative mb-1 block overflow-hidden rounded-xl",
		children: [src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
			src,
			className: "max-h-64 w-full object-cover",
			muted: true
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-36 w-56 bg-surface-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute inset-0 flex items-center justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex size-12 items-center justify-center rounded-full bg-black/45 text-white",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "ml-0.5 size-5 fill-current" })
			})
		})]
	});
}
function ReactionPicker({ onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex gap-1 rounded-full border border-border bg-surface p-1 shadow-[var(--shadow-float)]",
		children: REACTIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": item.label,
			onClick: () => onPick(item.id),
			className: "tap flex size-10 items-center justify-center rounded-full hover:bg-surface-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReactionIcon, {
				id: item.id,
				className: "size-5"
			})
		}, item.id))
	});
}
function Overlay({ open, onClose, children, className }) {
	if (!open) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-end justify-center sm:items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Закрыть",
			className: "absolute inset-0 bg-overlay fade-in",
			onClick: onClose
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("relative z-10 w-full max-w-lg scale-in rounded-t-3xl border border-border bg-surface p-4 shadow-[var(--shadow-float)] sm:rounded-3xl sm:p-5", className),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto mb-3 h-1 w-10 rounded-full bg-border-strong sm:hidden" }), children]
		})]
	});
}
function ComingSoonSheet({ title, body, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay, {
		open: true,
		onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-2 pb-3 pt-1 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mb-4 flex size-14 items-center justify-center rounded-2xl bg-accent-soft",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						viewBox: "0 0 24 24",
						className: "size-6 text-accent",
						"aria-hidden": "true",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
							d: "M12 3v3M12 18v3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M3 12h3M18 12h3M4.9 19.1 7 17M17 7l2.1-2.1",
							stroke: "currentColor",
							strokeWidth: "1.7",
							strokeLinecap: "round"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
							cx: "12",
							cy: "12",
							r: "3.2",
							fill: "currentColor"
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold tracking-tight",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm font-medium text-fg",
					children: "Эта функция в разработке"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onClose,
					className: "tap mt-5 h-11 w-full rounded-2xl bg-accent text-sm font-semibold text-accent-fg",
					children: "Понятно"
				})
			]
		})
	});
}
function ConfirmSheet({ title, body, confirmLabel, danger, onConfirm, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Overlay, {
		open: true,
		onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-1 pb-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold tracking-tight",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					children: body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						className: "tap h-11 rounded-2xl bg-surface-2 text-sm font-medium",
						children: "Отмена"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onConfirm,
						className: cn("tap h-11 rounded-2xl text-sm font-semibold", danger ? "bg-danger text-white" : "bg-accent text-accent-fg"),
						children: confirmLabel
					})]
				})
			]
		})
	});
}
function ChatView({ chatId, onBack }) {
	const chat = useTelechat((s) => s.chats.find((c) => c.id === chatId));
	const messages = useTelechat((s) => (s.messages[chatId] ?? []).filter((m) => !m.deletedForMe));
	const wallpaper = useTelechat((s) => s.wallpaper);
	const peer = useTelechat((s) => chat ? chatPeer(s, chat) : void 0);
	const scroller = (0, import_react.useRef)(null);
	const [menu, setMenu] = (0, import_react.useState)(null);
	const [headerMenu, setHeaderMenu] = (0, import_react.useState)(false);
	const [confirm, setConfirm] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const el = scroller.current;
		if (el) el.scrollTop = el.scrollHeight;
	}, [messages.length, chatId]);
	if (!chat) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-full items-center justify-center text-sm text-muted",
		children: "Чат не найден"
	});
	const typing = useTelechat((s) => s.contacts.some((c) => chat.participantIds.includes(c.id) && c.typing));
	const subtitle = chat.type === "group" ? formatMembers(chat.participantIds.length) : typing ? "печатает…" : peer && "online" in peer && peer.online ? t.online : peer && "lastSeen" in peer ? formatLastSeen(peer.lastSeen) : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("relative flex h-full min-h-0 flex-col", `app-wallpaper-${wallpaper}`),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-1 border-b border-border bg-bg-elevated/90 px-1 py-1.5 pt-[max(0.4rem,env(safe-area-inset-top))] backdrop-blur-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onBack,
						className: "tap flex size-11 items-center justify-center rounded-2xl md:hidden",
						"aria-label": "Назад",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => useTelechat.getState().setChatInfoOpen(true),
						className: "flex min-w-0 flex-1 items-center gap-3 rounded-2xl px-1 py-1 text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
							avatar: chat.avatar,
							size: "sm",
							online: peer && "online" in peer ? peer.online : false
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate font-semibold tracking-tight",
								children: chat.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block truncate text-xs text-muted",
								children: subtitle
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setHeaderMenu((v) => !v),
						className: "tap flex size-11 items-center justify-center rounded-2xl",
						"aria-label": "Ещё",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, { className: "size-5" })
					})
				]
			}),
			headerMenu ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute top-[4.2rem] right-3 z-20 w-56 overflow-hidden rounded-2xl border border-border bg-surface shadow-[var(--shadow-float)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
						icon: Pin,
						label: chat.pinned ? t.unpin : t.pin,
						onClick: () => {
							useTelechat.getState().pinChat(chatId, !chat.pinned);
							setHeaderMenu(false);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
						icon: BellOff,
						label: chat.muted ? t.unmute : t.mute,
						onClick: () => {
							useTelechat.getState().muteChat(chatId, !chat.muted);
							setHeaderMenu(false);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
						icon: Archive,
						label: chat.archived ? "Вернуть из архива" : t.archive,
						onClick: () => {
							useTelechat.getState().archiveChat(chatId, !chat.archived);
							setHeaderMenu(false);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
						icon: Info,
						label: "О чате",
						onClick: () => {
							useTelechat.getState().setChatInfoOpen(true);
							setHeaderMenu(false);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
						icon: Trash2,
						label: t.deleteForMe,
						danger: true,
						onClick: () => {
							setConfirm("chat-me");
							setHeaderMenu(false);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
						icon: Trash2,
						label: t.deleteForAll,
						danger: true,
						onClick: () => {
							setConfirm("chat-all");
							setHeaderMenu(false);
						}
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: scroller,
				className: "min-h-0 flex-1 space-y-1.5 overflow-y-auto px-3 py-3",
				children: messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-full flex-col items-center justify-center text-center text-sm text-muted",
					children: t.emptyMessages
				}) : messages.map((message, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageBubble, {
					message,
					grouped: i > 0 && messages[i - 1].senderId === message.senderId && message.createdAt - messages[i - 1].createdAt < 12e4,
					onLongPress: (m, x, y) => setMenu({
						message: m,
						x,
						y
					})
				}, message.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Composer, { chatId }),
			menu ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-40",
				onClick: () => setMenu(null),
				onContextMenu: (e) => e.preventDefault(),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute w-[220px]",
					style: {
						left: Math.min(menu.x, window.innerWidth - 230),
						top: Math.min(menu.y, window.innerHeight - 280)
					},
					onClick: (e) => e.stopPropagation(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReactionPicker, { onPick: (id) => {
						useTelechat.getState().toggleReaction(chatId, menu.message.id, id);
						setMenu(null);
					} }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 overflow-hidden rounded-2xl border border-border bg-surface shadow-[var(--shadow-float)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
								icon: Copy,
								label: t.copy,
								onClick: () => {
									useTelechat.getState().copyMessage(menu.message.id);
									setMenu(null);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
								icon: Forward,
								label: t.forward,
								onClick: () => {
									useTelechat.getState().setForwardMessage(menu.message.id);
									setMenu(null);
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
								icon: Trash2,
								label: t.deleteForMe,
								danger: true,
								onClick: () => {
									setConfirm("me");
								}
							}),
							menu.message.senderId === "user_me" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
								icon: Trash2,
								label: t.deleteForAll,
								danger: true,
								onClick: () => setConfirm("all")
							}) : null
						]
					})]
				})
			}) : null,
			confirm === "me" || confirm === "all" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmSheet, {
				title: confirm === "all" ? t.deleteForAll : t.deleteForMe,
				body: "Сообщение исчезнет из этой переписки.",
				confirmLabel: t.delete,
				danger: true,
				onClose: () => {
					setConfirm(null);
					setMenu(null);
				},
				onConfirm: () => {
					if (menu) useTelechat.getState().deleteMessage(chatId, menu.message.id, confirm === "all");
					setConfirm(null);
					setMenu(null);
				}
			}) : null,
			confirm === "chat-me" || confirm === "chat-all" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmSheet, {
				title: confirm === "chat-all" ? "Удалить чат у всех" : "Удалить чат у себя",
				body: "История переписки будет скрыта.",
				confirmLabel: t.delete,
				danger: true,
				onClose: () => setConfirm(null),
				onConfirm: () => {
					useTelechat.getState().deleteChat(chatId, confirm === "chat-all");
					setConfirm(null);
					onBack();
				}
			}) : null
		]
	});
}
function MenuItem({ icon: Icon, label, onClick, danger }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("flex h-11 w-full items-center gap-3 px-3 text-sm", danger ? "text-danger" : "text-fg"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), label]
	});
}
var FILTERS = [
	{
		id: "all",
		label: "Все"
	},
	{
		id: "unread",
		label: "Непрочитанные"
	},
	{
		id: "groups",
		label: "Группы"
	},
	{
		id: "muted",
		label: "Без звука"
	}
];
function ChatsList() {
	const chats = useTelechat(selectVisibleChats);
	const query = useTelechat((s) => s.ui.searchQuery);
	const filter = useTelechat((s) => s.ui.chatFilter);
	const archivedCount = useTelechat((s) => s.chats.filter((c) => c.archived && !c.deletedForMe).length);
	const showArchived = useTelechat((s) => s.ui.showArchived);
	const activeChatId = useTelechat((s) => s.ui.activeChatId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "px-4 pt-[max(0.9rem,env(safe-area-inset-top))] pb-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-[28px] font-semibold tracking-tight",
						children: showArchived ? t.archived : t.chats
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => useTelechat.getState().setCreateMode("direct"),
							className: "tap flex size-11 items-center justify-center rounded-2xl bg-surface text-fg",
							"aria-label": t.newChat,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => useTelechat.getState().setCreateMode("group"),
							className: "tap flex size-11 items-center justify-center rounded-2xl bg-accent text-accent-fg",
							"aria-label": t.newGroup,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "size-5" })
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "mt-3 flex h-11 items-center gap-2 rounded-2xl bg-surface px-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: query,
						onChange: (e) => useTelechat.getState().setSearchQuery(e.target.value),
						placeholder: t.searchChats,
						className: "h-full w-full bg-transparent text-[15px] outline-none placeholder:text-subtle"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "no-scrollbar mt-3 flex gap-2 overflow-x-auto",
					children: FILTERS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => useTelechat.getState().setChatFilter(item.id),
						className: cn("tap h-8 shrink-0 rounded-full px-3 text-xs font-medium", filter === item.id ? "bg-accent text-accent-fg" : "bg-surface text-muted"),
						children: item.label
					}, item.id))
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-h-0 flex-1 overflow-y-auto px-2 pb-2",
			children: [
				!showArchived && archivedCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => useTelechat.getState().setShowArchived(true),
					className: "tap mb-1 flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left hover:bg-surface",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-12 items-center justify-center rounded-full bg-surface-2 text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { className: "size-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: t.archive
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted",
							children: archivedCount
						})]
					})]
				}) : null,
				showArchived ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => useTelechat.getState().setShowArchived(false),
					className: "tap mb-2 px-3 text-sm font-medium text-accent",
					children: "К чатам"
				}) : null,
				chats.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex h-[48vh] flex-col items-center justify-center px-8 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex size-16 items-center justify-center rounded-3xl bg-surface",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-6 text-muted" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 font-semibold",
							children: showArchived ? t.emptyArchive : t.emptyChats
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: t.emptyChatsHint
						})
					]
				}) : chats.map((chat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => useTelechat.getState().openChat(chat.id),
					onContextMenu: (e) => {
						e.preventDefault();
						useTelechat.setState((s) => ({ ui: {
							...s.ui,
							selectedMessageId: chat.id
						} }));
					},
					className: cn("tap flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left", activeChatId === chat.id ? "bg-surface" : "hover:bg-surface/70"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, { avatar: chat.avatar }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate font-semibold tracking-tight",
										children: chat.title
									}),
									chat.muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BellOff, { className: "size-3.5 text-subtle" }) : null,
									chat.pinned ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pin, { className: "size-3.5 text-subtle" }) : null
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mt-0.5 block truncate text-sm text-muted",
								children: chat.lastMessagePreview || "Нет сообщений"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex flex-col items-end gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] text-subtle",
								children: formatChatTime(chat.lastMessageAt)
							}), chat.unread > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("min-w-5 rounded-full px-1.5 text-center text-[11px] font-semibold", chat.muted ? "bg-subtle text-bg" : "bg-accent text-accent-fg"),
								children: formatUnread(chat.unread)
							}) : null]
						})
					]
				}, chat.id))
			]
		})]
	});
}
function ContactsView() {
	const contacts = useTelechat(selectContacts);
	const query = useTelechat((s) => s.ui.contactQuery);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "px-4 pt-[max(0.9rem,env(safe-area-inset-top))] pb-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-[28px] font-semibold tracking-tight",
				children: t.contacts
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-3 flex h-11 items-center gap-2 rounded-2xl bg-surface px-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: query,
					onChange: (e) => useTelechat.getState().setContactQuery(e.target.value),
					placeholder: t.searchContacts,
					className: "h-full w-full bg-transparent text-[15px] outline-none placeholder:text-subtle"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-h-0 flex-1 overflow-y-auto px-2 pb-4",
			children: contacts.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-[48vh] flex-col items-center justify-center px-8 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex size-16 items-center justify-center rounded-3xl bg-surface",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "size-6 text-muted" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 font-semibold",
						children: t.emptyContacts
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Попробуйте @username из адресной книги."
					})
				]
			}) : contacts.map((contact) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => useTelechat.getState().createDirectChat(contact.id),
				className: "tap flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left hover:bg-surface",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
					avatar: contact.avatar,
					online: contact.online
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate font-semibold",
							children: contact.displayName
						}), contact.isOfficial ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "rounded-full bg-accent-soft px-1.5 py-0.5 text-[10px] font-semibold text-accent",
							children: "официальный"
						}) : null]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "block truncate text-sm text-muted",
						children: [
							contact.online ? t.online : formatLastSeen(contact.lastSeen),
							" · ",
							withAt(contact.username)
						]
					})]
				})]
			}, contact.id))
		})]
	});
}
function CreateDirectSheet() {
	const contacts = useTelechat((s) => s.contacts.filter((c) => !c.isBlocked));
	const [q, setQ] = (0, import_react.useState)("");
	const filtered = contacts.filter((c) => {
		const s = q.toLowerCase().replace(/^@/, "");
		if (!s) return true;
		return c.displayName.toLowerCase().includes(s) || c.username.includes(s);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
		open: true,
		onClose: () => useTelechat.getState().setCreateMode(null),
		className: "max-h-[82vh] overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold tracking-tight",
				children: t.newChat
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				autoFocus: true,
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: t.searchContacts,
				className: "mt-3 h-11 w-full rounded-2xl bg-surface-2 px-3 text-[15px] outline-none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 max-h-[50vh] overflow-y-auto",
				children: filtered.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => useTelechat.getState().createDirectChat(c.id),
					className: "tap flex w-full items-center gap-3 rounded-2xl px-1 py-2 text-left",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
						avatar: c.avatar,
						size: "sm",
						online: c.online
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate font-medium",
							children: c.displayName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-muted",
							children: ["@", c.username]
						})]
					})]
				}, c.id))
			})
		]
	});
}
function CreateGroupSheet() {
	const contacts = useTelechat((s) => s.contacts.filter((c) => !c.isOfficial && !c.isBlocked));
	const [title, setTitle] = (0, import_react.useState)("");
	const [picked, setPicked] = (0, import_react.useState)([]);
	const toggle = (id) => {
		setPicked((list) => list.includes(id) ? list.filter((x) => x !== id) : [...list, id]);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
		open: true,
		onClose: () => useTelechat.getState().setCreateMode(null),
		className: "max-h-[86vh] overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold tracking-tight",
				children: t.newGroup
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				autoFocus: true,
				value: title,
				onChange: (e) => setTitle(e.target.value),
				placeholder: t.groupName,
				className: "mt-3 h-11 w-full rounded-2xl bg-surface-2 px-3 text-[15px] outline-none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs font-medium text-muted",
				children: t.addMembers
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 max-h-[40vh] overflow-y-auto",
				children: contacts.map((c) => {
					const on = picked.includes(c.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => toggle(c.id),
						className: "tap flex w-full items-center gap-3 rounded-2xl px-1 py-2 text-left",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
								avatar: c.avatar,
								size: "sm"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "min-w-0 flex-1 font-medium",
								children: c.displayName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("flex size-5 items-center justify-center rounded-full border", on ? "border-accent bg-accent" : "border-border-strong") })
						]
					}, c.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: !title.trim() || picked.length === 0,
				onClick: () => useTelechat.getState().createGroup(title, picked),
				className: "tap mt-4 h-11 w-full rounded-2xl bg-accent text-sm font-semibold text-accent-fg disabled:opacity-40",
				children: t.create
			})
		]
	});
}
function ForwardSheet() {
	const messageId = useTelechat((s) => s.ui.forwardMessageId);
	const chats = useTelechat((s) => s.chats.filter((c) => !c.deletedForMe && !c.archived).sort((a, b) => b.lastMessageAt - a.lastMessageAt));
	if (!messageId) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
		open: true,
		onClose: () => useTelechat.getState().setForwardMessage(null),
		className: "max-h-[80vh] overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-lg font-semibold tracking-tight",
			children: t.forward
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 max-h-[55vh] overflow-y-auto",
			children: chats.map((chat) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => {
					useTelechat.getState().forwardMessage(messageId, chat.id);
					useTelechat.getState().openChat(chat.id);
				},
				className: "tap flex w-full items-center gap-3 rounded-2xl px-1 py-2 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
					avatar: chat.avatar,
					size: "sm"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "block truncate font-medium",
						children: chat.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted",
						children: chat.lastMessagePreview
					})]
				})]
			}, chat.id))
		})]
	});
}
function MediaViewer() {
	const viewer = useTelechat((s) => s.ui.mediaViewer);
	const message = useTelechat((s) => viewer ? findMessage(s, viewer.messageId) : void 0);
	const [src, setSrc] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const id = message?.photo?.mediaId ?? message?.video?.mediaId;
		if (!id) {
			setSrc(null);
			return;
		}
		getMedia(id).then(setSrc);
	}, [message]);
	if (!viewer || !message) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex flex-col bg-black/92",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => useTelechat.getState().openMedia("", null),
				className: "tap absolute top-[max(0.8rem,env(safe-area-inset-top))] right-3 z-10 flex size-11 items-center justify-center rounded-full bg-white/10 text-white",
				"aria-label": "Закрыть",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex min-h-0 flex-1 items-center justify-center p-4",
				children: message.type === "video" && src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
					src,
					controls: true,
					autoPlay: true,
					className: "max-h-full max-w-full rounded-2xl"
				}) : src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src,
					alt: message.text || "Медиа",
					className: "max-h-full max-w-full rounded-2xl object-contain"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-white/70",
					children: "Загрузка…"
				})
			}),
			message.text ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-6 pb-8 text-center text-sm text-white/80",
				children: message.text
			}) : null
		]
	});
}
function ProfileView() {
	const profile = useTelechat((s) => s.profile);
	const [edit, setEdit] = (0, import_react.useState)(null);
	const fileRef = (0, import_react.useRef)(null);
	if (!profile) return null;
	const onGallery = async (file) => {
		if (!file) return;
		const compressed = await compressImageFile(file);
		useTelechat.getState().setAvatar({
			kind: "image",
			src: compressed.dataUrl
		});
		setEdit(null);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "px-4 pt-[max(0.9rem,env(safe-area-inset-top))] pb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-[28px] font-semibold tracking-tight",
					children: t.profile
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-4 pb-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col items-center pt-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setEdit("avatar"),
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
									avatar: profile.avatar,
									size: "xl"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "absolute right-0 bottom-0 flex size-9 items-center justify-center rounded-full bg-accent text-accent-fg shadow-[var(--shadow-float)]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "size-4" })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-4 text-xl font-semibold tracking-tight",
								children: profile.displayName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-accent",
								children: withAt(profile.username)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 max-w-xs text-center text-sm text-muted",
								children: profile.bio
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 overflow-hidden rounded-3xl bg-surface",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldRow, {
								label: t.editName,
								value: profile.displayName,
								onClick: () => setEdit("name")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldRow, {
								label: t.editUsername,
								value: withAt(profile.username),
								onClick: () => setEdit("username")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldRow, {
								label: t.editBio,
								value: profile.bio || "Не указано",
								onClick: () => setEdit("bio")
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 overflow-hidden rounded-3xl bg-surface",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldRow, {
							label: t.devices,
							value: `${useTelechat.getState().devices.length}`,
							onClick: () => useTelechat.getState().setTab("settings")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldRow, {
							label: t.setPin,
							value: profile.pin ? "Включён" : "Выкл",
							onClick: () => useTelechat.getState().setTab("settings")
						})]
					}),
					profile.pin ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => useTelechat.getState().lock(),
						className: "tap mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-surface text-sm font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { className: "size-4" }), t.lock]
					}) : null
				]
			}),
			edit === "avatar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
				open: true,
				onClose: () => setEdit(null),
				className: "max-h-[86vh] overflow-y-auto",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: t.avatar
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => fileRef.current?.click(),
							className: "tap h-11 rounded-2xl bg-surface-2 text-sm font-medium",
							children: t.fromGallery
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								useTelechat.getState().setAvatar({
									kind: "gradient",
									hue: profile.displayName.length * 19,
									initials: profile.displayName.slice(0, 2).toUpperCase()
								});
								setEdit(null);
							},
							className: "tap h-11 rounded-2xl bg-surface-2 text-sm font-medium",
							children: "Инициалы"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						type: "file",
						accept: "image/*",
						hidden: true,
						onChange: (e) => void onGallery(e.target.files?.[0])
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-xs font-medium text-muted",
						children: t.animals
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 grid grid-cols-4 gap-2",
						children: ANIMALS.map((animal) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								useTelechat.getState().setAnimalAvatar(animal.id);
								setEdit(null);
							},
							className: cn("tap flex flex-col items-center gap-1 rounded-2xl p-2", profile.avatar.kind === "animal" && profile.avatar.animal === animal.id ? "bg-accent-soft" : "bg-surface-2"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserAvatar, {
								avatar: {
									kind: "animal",
									animal: animal.id
								},
								size: "md"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-[11px] text-muted",
								children: animal.label
							})]
						}, animal.id))
					})
				]
			}) : null,
			edit === "name" || edit === "username" || edit === "bio" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditText, {
				kind: edit,
				initial: edit === "name" ? profile.displayName : edit === "username" ? profile.username : profile.bio,
				onClose: () => setEdit(null)
			}) : null
		]
	});
}
function FieldRow({ label, value, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "tap flex min-h-14 w-full items-center gap-3 px-4 text-left",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block text-xs text-muted",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block font-medium",
				children: value
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4 text-subtle" })]
	});
}
function EditText({ kind, initial, onClose }) {
	const [value, setValue] = (0, import_react.useState)(initial);
	const [error, setError] = (0, import_react.useState)(null);
	const save = () => {
		if (kind === "name") {
			if (!isValidDisplayName(value)) {
				setError("Имя: 2–48 символов");
				return;
			}
			useTelechat.getState().updateProfile({ displayName: value.trim() });
		} else if (kind === "username") {
			const err = usernameError(value);
			if (err) {
				setError(err);
				return;
			}
			if (!isValidUsername(value)) {
				setError(t.invalidUsername);
				return;
			}
			if (useTelechat.getState().contacts.some((c) => c.username === normalizeUsername(value))) {
				setError(t.usernameTaken);
				return;
			}
			useTelechat.getState().updateProfile({ username: normalizeUsername(value) });
		} else useTelechat.getState().updateProfile({ bio: value.trim().slice(0, 140) });
		onClose();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
		open: true,
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold",
				children: kind === "name" ? t.editName : kind === "username" ? t.editUsername : t.editBio
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				autoFocus: true,
				value,
				onChange: (e) => setValue(kind === "username" ? e.target.value.replace(/^@/, "") : e.target.value),
				className: "mt-4 h-12 w-full rounded-2xl bg-surface-2 px-4 text-[16px] outline-none"
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: save,
				className: "tap mt-4 flex h-11 w-full items-center justify-center gap-2 rounded-2xl bg-accent text-sm font-semibold text-accent-fg",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }), t.save]
			})
		]
	});
}
function SettingsView() {
	const theme = useTelechat((s) => s.theme);
	const profile = useTelechat((s) => s.profile);
	const [panel, setPanel] = (0, import_react.useState)(null);
	const [confirmLogout, setConfirmLogout] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "px-4 pt-[max(0.9rem,env(safe-area-inset-top))] pb-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-[28px] font-semibold tracking-tight",
					children: t.settings
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-4 pb-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							icon: theme === "dark" ? Moon : Sun,
							label: t.theme,
							value: theme === "dark" ? t.dark : t.light,
							onClick: () => setPanel("appearance")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							icon: Palette,
							label: t.appearance,
							onClick: () => setPanel("appearance")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							icon: Bell,
							label: t.notifications,
							onClick: () => setPanel("notify")
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							icon: Lock,
							label: t.setPin,
							value: profile?.pin ? "Включён" : "Выкл",
							onClick: () => setPanel("pin")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							icon: Shield,
							label: t.privacy,
							onClick: () => setPanel("privacy")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							icon: Smartphone,
							label: t.devices,
							onClick: () => setPanel("devices")
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							icon: Phone,
							label: "Звонки",
							onClick: () => useTelechat.getState().setComingSoon("calls")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							icon: Sparkles,
							label: "Истории",
							onClick: () => useTelechat.getState().setComingSoon("stories")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
							icon: CircleHelp,
							label: t.help,
							onClick: () => useTelechat.getState().setComingSoon("bots")
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setConfirmLogout(true),
						className: "tap mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-surface text-sm font-medium text-danger",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), t.logout]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-6 text-center text-xs text-subtle",
						children: ["TeleChat ", t.version]
					})
				]
			}),
			panel === "appearance" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppearancePanel, { onClose: () => setPanel(null) }) : null,
			panel === "pin" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PinPanel, { onClose: () => setPanel(null) }) : null,
			panel === "devices" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DevicesPanel, { onClose: () => setPanel(null) }) : null,
			panel === "privacy" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrivacyPanel, { onClose: () => setPanel(null) }) : null,
			panel === "notify" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotifyPanel, { onClose: () => setPanel(null) }) : null,
			confirmLogout ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmSheet, {
				title: "Выйти из аккаунта?",
				body: "Переписка останется на этом устройстве, пока вы не очистите данные.",
				confirmLabel: t.logout,
				danger: true,
				onClose: () => setConfirmLogout(false),
				onConfirm: () => {
					useTelechat.getState().logout();
					setConfirmLogout(false);
				}
			}) : null
		]
	});
}
function Section({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mb-3 overflow-hidden rounded-3xl bg-surface",
		children
	});
}
function Row({ icon: Icon, label, value, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: "tap flex min-h-12 w-full items-center gap-3 px-4 py-2.5 text-left",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex size-9 items-center justify-center rounded-xl bg-surface-2 text-accent",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex-1 font-medium",
				children: label
			}),
			value ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm text-muted",
				children: value
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 text-subtle" })
		]
	});
}
function AppearancePanel({ onClose }) {
	const theme = useTelechat((s) => s.theme);
	const wallpaper = useTelechat((s) => s.wallpaper);
	const fontSize = useTelechat((s) => s.profile?.fontSize ?? "medium");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
		open: true,
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold",
				children: t.appearance
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid grid-cols-2 gap-2",
				children: ["dark", "light"].map((mode) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => useTelechat.getState().setTheme(mode),
					className: cn("tap h-11 rounded-2xl text-sm font-medium", theme === mode ? "bg-accent text-accent-fg" : "bg-surface-2"),
					children: mode === "dark" ? t.dark : t.light
				}, mode))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-xs font-medium text-muted",
				children: t.wallpaper
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 grid grid-cols-5 gap-2",
				children: WALLPAPERS.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						useTelechat.setState({ wallpaper: w.id });
						useTelechat.getState().persist();
					},
					className: cn("h-10 rounded-xl", `app-wallpaper-${w.id}`, wallpaper === w.id && "ring-2 ring-accent"),
					"aria-label": w.label
				}, w.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 text-xs font-medium text-muted",
				children: t.fontSize
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 grid grid-cols-3 gap-2",
				children: [
					"small",
					"medium",
					"large"
				].map((size) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => useTelechat.getState().updateProfile({ fontSize: size }),
					className: cn("tap h-11 rounded-2xl text-sm", fontSize === size ? "bg-accent text-accent-fg" : "bg-surface-2"),
					children: t[size]
				}, size))
			})
		]
	});
}
function PinPanel({ onClose }) {
	const current = useTelechat((s) => s.profile?.pin);
	const [value, setValue] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
		open: true,
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold",
				children: t.setPin
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: t.pinHint
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				inputMode: "numeric",
				value,
				onChange: (e) => setValue(e.target.value.replace(/\D/g, "").slice(0, 6)),
				placeholder: "••••••",
				className: "mt-4 h-12 w-full rounded-2xl bg-surface-2 px-4 text-center text-lg tracking-[0.4em] outline-none"
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-danger",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					if (!isValidPin(value)) {
						setError("Нужно ровно 6 цифр");
						return;
					}
					useTelechat.getState().setPin(value);
					onClose();
				},
				className: "tap mt-4 h-11 w-full rounded-2xl bg-accent text-sm font-semibold text-accent-fg",
				children: "Сохранить код"
			}),
			current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => {
					useTelechat.getState().setPin(null);
					onClose();
				},
				className: "tap mt-2 h-11 w-full rounded-2xl text-sm text-danger",
				children: "Отключить"
			}) : null
		]
	});
}
function DevicesPanel({ onClose }) {
	const devices = useTelechat((s) => s.devices);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
		open: true,
		onClose,
		className: "max-h-[80vh] overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-lg font-semibold",
			children: t.devices
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 space-y-2",
			children: devices.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3 rounded-2xl bg-surface-2 px-3 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "size-5 text-muted" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-medium",
							children: [
								d.name,
								" ",
								d.current ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-accent",
									children: ["· ", t.currentDevice]
								}) : null
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xs text-muted",
							children: [
								d.location,
								" · ",
								formatChatTime(d.lastActive)
							]
						})]
					}),
					!d.current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => useTelechat.getState().terminateDevice(d.id),
						className: "text-xs font-medium text-danger",
						children: t.terminate
					}) : null
				]
			}, d.id))
		})]
	});
}
function PrivacyPanel({ onClose }) {
	const profile = useTelechat((s) => s.profile);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
		open: true,
		onClose,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-semibold",
				children: t.privacy
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs font-medium text-muted",
				children: t.lastSeenPrivacy
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2 grid grid-cols-3 gap-2",
				children: [
					"everyone",
					"contacts",
					"nobody"
				].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => useTelechat.getState().updateProfile({ lastSeenPrivacy: v }),
					className: cn("tap h-10 rounded-2xl text-xs font-medium", profile?.lastSeenPrivacy === v ? "bg-accent text-accent-fg" : "bg-surface-2"),
					children: v === "everyone" ? t.everyone : v === "contacts" ? t.contactsOnly : t.nobody
				}, v))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => useTelechat.getState().updateProfile({ readReceipts: !profile?.readReceipts }),
				className: "tap mt-4 flex h-12 w-full items-center justify-between rounded-2xl bg-surface-2 px-4 text-sm",
				children: [t.readReceipts, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-5 rounded-full", profile?.readReceipts ? "bg-accent" : "bg-border-strong") })]
			})
		]
	});
}
function NotifyPanel({ onClose }) {
	const profile = useTelechat((s) => s.profile);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Overlay, {
		open: true,
		onClose,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-lg font-semibold",
			children: t.notifications
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => useTelechat.getState().updateProfile({ notificationSound: !profile?.notificationSound }),
			className: "tap mt-4 flex h-12 w-full items-center justify-between rounded-2xl bg-surface-2 px-4 text-sm",
			children: [t.sound, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-5 rounded-full", profile?.notificationSound ? "bg-accent" : "bg-border-strong") })]
		})]
	});
}
function TelechatApp() {
	const hydrated = useTelechat((s) => s.hydrated);
	const authStep = useTelechat((s) => s.authStep);
	const locked = useTelechat((s) => Boolean(s.session?.locked && s.profile?.pin));
	const tab = useTelechat((s) => s.ui.tab);
	const activeChatId = useTelechat((s) => s.ui.activeChatId);
	const createMode = useTelechat((s) => s.ui.createMode);
	const comingSoon = useTelechat((s) => s.ui.comingSoon);
	const chatInfoOpen = useTelechat((s) => s.ui.chatInfoOpen);
	const fontSize = useTelechat((s) => s.profile?.fontSize ?? "medium");
	(0, import_react.useEffect)(() => {
		useTelechat.getState().hydrate();
		const timer = window.setInterval(() => useTelechat.getState().tickPresence(), 2e4);
		return () => window.clearInterval(timer);
	}, []);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, {});
	if (authStep !== "app") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthFlow, {});
	if (locked) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PinLock, {});
	const chatOpen = Boolean(activeChatId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("mx-auto flex h-dvh max-w-6xl bg-bg", fontSize === "small" ? "text-[14.5px]" : fontSize === "large" ? "text-[17px]" : "text-[16px]"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: cn("flex min-h-0 w-full flex-col border-border md:max-w-[380px] md:border-r", chatOpen ? "hidden md:flex" : "flex"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-h-0 flex-1",
					children: [
						tab === "chats" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatsList, {}) : null,
						tab === "contacts" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactsView, {}) : null,
						tab === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsView, {}) : null,
						tab === "profile" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileView, {}) : null
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BottomNav, {})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: cn("relative min-h-0 min-w-0 flex-1", chatOpen ? "flex" : "hidden md:flex"),
				children: activeChatId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative min-h-0 w-full",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatView, {
						chatId: activeChatId,
						onBack: () => useTelechat.getState().openChat(null)
					}), chatInfoOpen ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatInfo, {
						chatId: activeChatId,
						onClose: () => useTelechat.getState().setChatInfoOpen(false)
					}) : null]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyPane, {})
			}),
			createMode === "direct" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateDirectSheet, {}) : null,
			createMode === "group" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateGroupSheet, {}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ForwardSheet, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaViewer, {}),
			comingSoon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComingSoonSheet, {
				title: COMING_SOON[comingSoon].title,
				body: COMING_SOON[comingSoon].body,
				onClose: () => useTelechat.getState().setComingSoon(null)
			}) : null
		]
	});
}
function EmptyPane() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "app-wallpaper-ink hidden h-full w-full flex-col items-center justify-center px-8 text-center md:flex",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-semibold tracking-tight",
				children: "Выберите чат"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm leading-relaxed text-muted",
				children: "Слева — переписки и группы. Напишите сообщение, запишите голос или отправьте кадр из галереи."
			})]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TelechatApp, {});
}
//#endregion
export { Home as component };
