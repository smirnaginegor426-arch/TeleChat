import { createFileRoute } from "@tanstack/react-router";
import { TelechatApp } from "@/components/telechat/app-shell";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <TelechatApp />;
}
