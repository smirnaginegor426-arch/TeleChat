import { createId } from "./ids";
import { putMedia } from "./storage";

export function peaksFromSamples(samples: number[], buckets = 36): number[] {
  if (samples.length === 0) {
    return Array.from({ length: buckets }, () => 0.15);
  }
  const size = Math.max(1, Math.floor(samples.length / buckets));
  const peaks: number[] = [];
  for (let i = 0; i < buckets; i += 1) {
    let max = 0;
    const start = i * size;
    for (let j = start; j < start + size && j < samples.length; j += 1) {
      max = Math.max(max, Math.abs(samples[j]));
    }
    peaks.push(Math.max(0.08, Math.min(1, max)));
  }
  return peaks;
}

export function fakePeaks(seed: number, buckets = 36): number[] {
  const peaks: number[] = [];
  let x = seed || 1;
  for (let i = 0; i < buckets; i += 1) {
    x = (x * 16807) % 2147483647;
    const wave = 0.35 + 0.55 * Math.abs(Math.sin(i / 2.7 + seed));
    peaks.push(Math.max(0.1, Math.min(1, wave * (0.55 + (x % 100) / 180))));
  }
  return peaks;
}

export async function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

export async function storeVoiceBlob(
  blob: Blob,
  durationMs: number,
  peaks: number[],
): Promise<{ mediaId: string; durationMs: number; peaks: number[] }> {
  const mediaId = createId("voc");
  const dataUrl = await blobToDataUrl(blob);
  await putMedia(mediaId, dataUrl);
  return { mediaId, durationMs, peaks };
}

export function createRecorder(): {
  start: () => Promise<void>;
  stop: () => Promise<{ blob: Blob; durationMs: number; peaks: number[] }>;
  cancel: () => void;
} {
  let recorder: MediaRecorder | null = null;
  let chunks: Blob[] = [];
  let started = 0;
  let stream: MediaStream | null = null;
  let peaks: number[] = [];
  let analyser: AnalyserNode | null = null;
  let audioCtx: AudioContext | null = null;
  let raf = 0;
  const samples: number[] = [];

  const tick = () => {
    if (!analyser) return;
    const buf = new Uint8Array(analyser.fftSize);
    analyser.getByteTimeDomainData(buf);
    let peak = 0;
    for (let i = 0; i < buf.length; i += 1) {
      peak = Math.max(peak, Math.abs(buf[i] - 128) / 128);
    }
    samples.push(peak);
    raf = requestAnimationFrame(tick);
  };

  return {
    async start() {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioCtx = new AudioContext();
      const source = audioCtx.createMediaStreamSource(stream);
      analyser = audioCtx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);
      chunks = [];
      samples.length = 0;
      started = Date.now();
      const mime = MediaRecorder.isTypeSupported("audio/webm")
        ? "audio/webm"
        : "";
      recorder = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) chunks.push(event.data);
      };
      recorder.start(80);
      tick();
    },
    stop() {
      return new Promise((resolve, reject) => {
        if (!recorder) {
          reject(new Error("not recording"));
          return;
        }
        recorder.onstop = () => {
          cancelAnimationFrame(raf);
          stream?.getTracks().forEach((tr) => tr.stop());
          void audioCtx?.close();
          peaks = peaksFromSamples(samples);
          const blob = new Blob(chunks, { type: recorder?.mimeType || "audio/webm" });
          resolve({ blob, durationMs: Date.now() - started, peaks });
          recorder = null;
        };
        recorder.stop();
      });
    },
    cancel() {
      cancelAnimationFrame(raf);
      try {
        recorder?.stop();
      } catch {
        /* ignore */
      }
      stream?.getTracks().forEach((tr) => tr.stop());
      void audioCtx?.close();
      recorder = null;
    },
  };
}

export function playChime(enabled: boolean) {
  if (!enabled || typeof AudioContext === "undefined") return;
  const ctx = new AudioContext();
  const now = ctx.currentTime;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = "sine";
  osc.frequency.setValueAtTime(880, now);
  osc.frequency.exponentialRampToValueAtTime(1320, now + 0.08);
  gain.gain.setValueAtTime(0.0001, now);
  gain.gain.exponentialRampToValueAtTime(0.08, now + 0.02);
  gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.22);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start(now);
  osc.stop(now + 0.24);
  osc.onended = () => void ctx.close();
}
