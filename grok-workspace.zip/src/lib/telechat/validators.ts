import { PIN_LENGTH, USERNAME_MAX, USERNAME_MIN } from "./constants";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
const USERNAME_RE = /^[a-zA-Z][a-zA-Z0-9_]{4,31}$/;
const PIN_RE = /^\d{6}$/;

export function isValidEmail(value: string): boolean {
  return EMAIL_RE.test(value.trim());
}

export function normalizeUsername(value: string): string {
  return value.trim().replace(/^@/, "").toLowerCase();
}

export function isValidUsername(value: string): boolean {
  const v = normalizeUsername(value);
  if (v.length < USERNAME_MIN || v.length > USERNAME_MAX) return false;
  return USERNAME_RE.test(v);
}

export function isValidDisplayName(value: string): boolean {
  const v = value.trim();
  return v.length >= 2 && v.length <= 48;
}

export function isValidPin(value: string): boolean {
  return PIN_RE.test(value) && value.length === PIN_LENGTH;
}

export function isValidCode(value: string, expected: string): boolean {
  return value.trim() === expected;
}

export function usernameError(value: string): string | null {
  const v = normalizeUsername(value);
  if (!v) return "Укажите юзернейм";
  if (v.length < USERNAME_MIN) return "Минимум 5 символов";
  if (v.length > USERNAME_MAX) return "Максимум 32 символа";
  if (!/^[a-zA-Z]/.test(v)) return "Должен начинаться с буквы";
  if (!/^[a-zA-Z0-9_]+$/.test(v)) return "Только латиница, цифры и _";
  return null;
}
