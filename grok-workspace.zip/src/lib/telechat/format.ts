import { t } from "./constants";

const MONTHS_SHORT = [
  "янв",
  "фев",
  "мар",
  "апр",
  "мая",
  "июн",
  "июл",
  "авг",
  "сен",
  "окт",
  "ноя",
  "дек",
];

const MONTHS_LONG = [
  "января",
  "февраля",
  "марта",
  "апреля",
  "мая",
  "июня",
  "июля",
  "августа",
  "сентября",
  "октября",
  "ноября",
  "декабря",
];

function startOfDay(ts: number): number {
  const d = new Date(ts);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

export function pad2(n: number): string {
  return n.toString().padStart(2, "0");
}

export function formatTime(ts: number): string {
  const d = new Date(ts);
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
}

export function formatDayLabel(ts: number, now = Date.now()): string {
  const day = startOfDay(ts);
  const today = startOfDay(now);
  const diff = today - day;
  if (diff === 0) return t.today;
  if (diff === 86_400_000) return t.yesterday;
  const d = new Date(ts);
  return `${d.getDate()} ${MONTHS_LONG[d.getMonth()]}`;
}

export function formatChatTime(ts: number, now = Date.now()): string {
  const day = startOfDay(ts);
  const today = startOfDay(now);
  const diff = today - day;
  if (diff === 0) return formatTime(ts);
  if (diff === 86_400_000) return t.yesterday;
  const d = new Date(ts);
  if (d.getFullYear() === new Date(now).getFullYear()) {
    return `${d.getDate()} ${MONTHS_SHORT[d.getMonth()]}`;
  }
  return `${pad2(d.getDate())}.${pad2(d.getMonth() + 1)}.${d.getFullYear()}`;
}

export function formatLastSeen(ts: number, now = Date.now()): string {
  const delta = Math.max(0, now - ts);
  if (delta < 20_000) return t.justNow;
  if (delta < 60_000) return `${Math.floor(delta / 1000)} с`;
  if (delta < 3_600_000) return `${Math.floor(delta / 60_000)} мин`;
  if (delta < 22 * 3_600_000) return `${Math.floor(delta / 3_600_000)} ч`;
  return `${t.lastSeen} ${formatChatTime(ts, now)}`.toLowerCase();
}

export function formatDuration(ms: number): string {
  const total = Math.max(0, Math.round(ms / 1000));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${pad2(s)}`;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} Б`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} КБ`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} МБ`;
}

export function formatMembers(count: number): string {
  const mod10 = count % 10;
  const mod100 = count % 100;
  if (mod10 === 1 && mod100 !== 11) return `${count} участник`;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) {
    return `${count} участника`;
  }
  return `${count} участников`;
}

export function formatUnread(count: number): string {
  if (count > 99) return "99+";
  return String(count);
}

export function pluralMessages(count: number): string {
  const mod10 = count % 10;
  const mod100 = count % 100;
  if (mod10 === 1 && mod100 !== 11) return `${count} сообщение`;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) {
    return `${count} сообщения`;
  }
  return `${count} сообщений`;
}

export function withAt(username: string): string {
  const clean = username.replace(/^@/, "");
  return `@${clean}`;
}

export function clampText(text: string, max = 72): string {
  const clean = text.replace(/\s+/g, " ").trim();
  if (clean.length <= max) return clean;
  return `${clean.slice(0, max - 1)}…`;
}
