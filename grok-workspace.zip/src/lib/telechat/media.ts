import { MAX_IMAGE_EDGE } from "./constants";
import { createId } from "./ids";
import { putMedia } from "./storage";

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

export async function compressImageFile(file: File): Promise<{
  dataUrl: string;
  width: number;
  height: number;
}> {
  const raw = await fileToDataUrl(file);
  return compressDataUrl(raw);
}

export function compressDataUrl(
  dataUrl: string,
  maxEdge = MAX_IMAGE_EDGE,
  quality = 0.72,
): Promise<{ dataUrl: string; width: number; height: number }> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxEdge / Math.max(img.width, img.height));
      const width = Math.max(1, Math.round(img.width * scale));
      const height = Math.max(1, Math.round(img.height * scale));
      const canvas = document.createElement("canvas");
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");
      if (!ctx) {
        resolve({ dataUrl, width: img.width, height: img.height });
        return;
      }
      ctx.drawImage(img, 0, 0, width, height);
      const out = canvas.toDataURL("image/jpeg", quality);
      resolve({ dataUrl: out, width, height });
    };
    img.onerror = () => resolve({ dataUrl, width: 1, height: 1 });
    img.src = dataUrl;
  });
}

export async function storeImageFile(file: File): Promise<{
  mediaId: string;
  width: number;
  height: number;
}> {
  const compressed = await compressImageFile(file);
  const mediaId = createId("img");
  await putMedia(mediaId, compressed.dataUrl);
  return { mediaId, width: compressed.width, height: compressed.height };
}

export async function storeVideoFile(file: File): Promise<{
  mediaId: string;
  durationMs: number;
  width: number;
  height: number;
}> {
  const dataUrl = await fileToDataUrl(file);
  const mediaId = createId("vid");
  await putMedia(mediaId, dataUrl);
  const meta = await readVideoMeta(dataUrl);
  return { mediaId, ...meta };
}

export function readVideoMeta(src: string): Promise<{
  durationMs: number;
  width: number;
  height: number;
}> {
  return new Promise((resolve) => {
    const video = document.createElement("video");
    video.preload = "metadata";
    video.onloadedmetadata = () => {
      resolve({
        durationMs: Math.round((video.duration || 0) * 1000),
        width: video.videoWidth || 640,
        height: video.videoHeight || 360,
      });
    };
    video.onerror = () =>
      resolve({ durationMs: 0, width: 640, height: 360 });
    video.src = src;
  });
}

export function makePatternPhoto(seed: string, w = 720, h = 480): string {
  const hue = Array.from(seed).reduce((a, c) => a + c.charCodeAt(0), 0) % 360;
  const hue2 = (hue + 38) % 360;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}">
    <defs>
      <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="hsl(${hue} 38% 28%)"/>
        <stop offset="1" stop-color="hsl(${hue2} 32% 16%)"/>
      </linearGradient>
    </defs>
    <rect width="${w}" height="${h}" fill="url(#g)"/>
    <circle cx="${w * 0.72}" cy="${h * 0.28}" r="${h * 0.22}" fill="hsl(${hue} 50% 62% / 0.35)"/>
    <circle cx="${w * 0.22}" cy="${h * 0.7}" r="${h * 0.18}" fill="hsl(${hue2} 40% 70% / 0.22)"/>
    <rect x="${w * 0.12}" y="${h * 0.18}" width="${w * 0.28}" height="${h * 0.08}" rx="8" fill="white" fill-opacity="0.12"/>
  </svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

export function estimateStateBytes(value: unknown): number {
  try {
    return new Blob([JSON.stringify(value)]).size;
  } catch {
    return 0;
  }
}
