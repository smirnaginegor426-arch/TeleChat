import type { Contact } from "./types";

const GENERIC = [
  "Ок, понял.",
  "Сейчас гляну и отвечу.",
  "Ха, хорошо.",
  "Давай так.",
  "Напишу чуть позже.",
  "Согласен.",
  "Интересно. Расскажи ещё.",
  "Супер, спасибо!",
];

const KEYWORD_REPLIES: Array<{ test: RegExp; replies: string[] }> = [
  {
    test: /привет|здравств|хай|йоу|добр/i,
    replies: [
      "Привет! Как дела?",
      "Здорово. Рад тебя видеть.",
      "Привет-привет!",
    ],
  },
  {
    test: /как дела|что нового|как ты/i,
    replies: [
      "Нормально, в работе. А у тебя?",
      "Всё спокойно. Вечером свободен.",
      "Отлично, только что закончил задачу.",
    ],
  },
  {
    test: /фото|картин|снимок/i,
    replies: ["Классный кадр.", "Выглядит здорово.", "Ого, круто снято."],
  },
  {
    test: /голос|слушай|аудио/i,
    replies: ["Прослушал. Ок.", "Понял тебя.", "Сейчас переслушаю ещё раз."],
  },
  {
    test: /встрет|кофе|чай|пойдём|пойдем/i,
    replies: [
      "Давай. Завтра после шести нормально?",
      "Могу в пятницу.",
      "Ок, кидай место.",
    ],
  },
  {
    test: /\?/,
    replies: [
      "Хороший вопрос. Дай подумать.",
      "Думаю, да.",
      "Скорее нет, но могу уточнить.",
    ],
  },
  {
    test: /спасибо|благодар/i,
    replies: ["Всегда пожалуйста.", "Не за что.", "Обращайся."],
  },
  {
    test: /ок|хорошо|ладно|договорились/i,
    replies: ["Отлично.", "Договорились.", "Жду."],
  },
];

const PERSONALITY: Record<string, string[]> = {
  user_anna: [
    "Макет уже в Figma, кину ссылку вечером.",
    "Давай без лишнего — короткий текст на карточке.",
    "Цвет акцента лучше чуть холоднее.",
  ],
  user_dmitry: [
    "Ха, это сильно.",
    "Пойдём в зал в четверг?",
    "Кинь адрес, я рядом.",
  ],
  user_mom: [
    "Ты поел?",
    "Хорошо, родной. Не засиживайся.",
    "Позвони, как будешь свободен.",
  ],
  user_elena: [
    "Статус по задаче: в работе, вечером обновлю доску.",
    "Нужен апдейт к 18:00.",
    "Согласую с командой и вернусь.",
  ],
  user_max: [
    "Сегодня 5×5, потом кардио.",
    "Не забудь протеин.",
    "Завтра в 7:30 у входа.",
  ],
  user_sofia: [
    "Конспект скину после пары.",
    "Там на слайде 14 как раз это.",
    "Можем созвониться на 20 минут.",
  ],
  user_alexey: [
    "Я на этаже, если что — стучи.",
    "Почта в ящике, кстати.",
    "Вечером тихо будет, ремонт закончили.",
  ],
  user_irina: [
    "Мама уже спрашивала, когда ты приедешь.",
    "Фото с выходных просто огонь.",
    "Купи хлеб, если будешь в магазине.",
  ],
  user_nikita: [
    "Го в катку после девяти.",
    "Патч вышел, там нерфнули ту пушку.",
    "GG, реванш?",
  ],
  user_telechat: [
    "Это автоматическое сообщение TeleChat. Мы рядом, если что-то сломается.",
    "Подсказка: зажмите сообщение, чтобы поставить реакцию.",
    "Код-пароль можно включить в Настройках.",
  ],
};

export function pickReply(contact: Contact, text: string): string {
  for (const rule of KEYWORD_REPLIES) {
    if (rule.test.test(text)) {
      return pick(rule.replies, contact.id);
    }
  }
  const personal = PERSONALITY[contact.id];
  if (personal && Math.random() > 0.35) return pick(personal, text.length);
  return pick(GENERIC, contact.id.length + text.length);
}

export function pickGroupReply(
  senderName: string,
  text: string,
): { speakerOffset: number; text: string } {
  const replies = [
    `${senderName}, плюсую.`,
    "Давайте зафиксируем это.",
    "Могу взять на себя.",
    "Ок, тогда без меня завтра — пишите итог.",
    "Звучит разумно.",
  ];
  if (/\?/.test(text)) {
    replies.unshift("Могу уточнить и написать сюда.");
  }
  return {
    speakerOffset: (text.length + senderName.length) % 3,
    text: pick(replies, text.length),
  };
}

function pick(list: string[], seed: string | number): string {
  const n =
    typeof seed === "number"
      ? seed
      : Array.from(String(seed)).reduce((a, c) => a + c.charCodeAt(0), 0);
  return list[Math.abs(n) % list.length] ?? list[0];
}

export function replyDelay(online: boolean): number {
  if (online) return 700 + Math.floor(Math.random() * 1100);
  return 1400 + Math.floor(Math.random() * 2200);
}
