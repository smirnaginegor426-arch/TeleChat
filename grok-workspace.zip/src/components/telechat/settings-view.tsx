import type { ReactNode } from "react";
import {
  Bell,
  ChevronRight,
  CircleHelp,
  Lock,
  LogOut,
  Moon,
  Palette,
  Phone,
  Shield,
  Smartphone,
  Sparkles,
  Sun,
} from "lucide-react";
import { useState } from "react";
import { NumericKeypad, PinDots } from "@/components/telechat/numeric-keypad";
import { ConfirmSheet, Overlay } from "@/components/telechat/sheet";
import { t, WALLPAPERS } from "@/lib/telechat/constants";
import { PIN_LENGTH } from "@/lib/telechat/constants";
import { formatChatTime } from "@/lib/telechat/format";
import { isValidPin } from "@/lib/telechat/validators";
import { useTelechat } from "@/store/telechat-store";
import { cn } from "@/lib/utils";

export function SettingsView() {
  const theme = useTelechat((s) => s.theme);
  const profile = useTelechat((s) => s.profile);
  const [panel, setPanel] = useState<null | "pin" | "devices" | "appearance" | "privacy" | "notify">(null);
  const [confirmLogout, setConfirmLogout] = useState(false);

  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="px-4 pt-[max(0.9rem,env(safe-area-inset-top))] pb-3">
        <h1 className="text-[28px] font-semibold tracking-tight">{t.settings}</h1>
      </header>
      <div className="min-h-0 flex-1 overflow-y-auto px-4 pb-8">
        <Section>
          <Row icon={theme === "dark" ? Moon : Sun} label={t.theme} value={theme === "dark" ? t.dark : t.light} onClick={() => setPanel("appearance")} />
          <Row icon={Palette} label={t.appearance} onClick={() => setPanel("appearance")} />
          <Row icon={Bell} label={t.notifications} onClick={() => setPanel("notify")} />
        </Section>
        <Section>
          <Row icon={Lock} label={t.setPin} value={profile?.pin ? "Включён" : "Выкл"} onClick={() => setPanel("pin")} />
          <Row icon={Shield} label={t.privacy} onClick={() => setPanel("privacy")} />
          <Row icon={Smartphone} label={t.devices} onClick={() => setPanel("devices")} />
        </Section>
        <Section>
          <Row icon={Phone} label="Звонки" onClick={() => useTelechat.getState().setComingSoon("calls")} />
          <Row icon={Sparkles} label="Истории" onClick={() => useTelechat.getState().setComingSoon("stories")} />
          <Row icon={CircleHelp} label={t.help} onClick={() => useTelechat.getState().setComingSoon("bots")} />
        </Section>
        <button
          type="button"
          onClick={() => setConfirmLogout(true)}
          className="tap mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-2xl bg-surface text-sm font-medium text-danger"
        >
          <LogOut className="size-4" />
          {t.logout}
        </button>
        <p className="mt-6 text-center text-xs text-subtle">TeleChat {t.version}</p>
      </div>

      {panel === "appearance" ? <AppearancePanel onClose={() => setPanel(null)} /> : null}
      {panel === "pin" ? <PinPanel onClose={() => setPanel(null)} /> : null}
      {panel === "devices" ? <DevicesPanel onClose={() => setPanel(null)} /> : null}
      {panel === "privacy" ? <PrivacyPanel onClose={() => setPanel(null)} /> : null}
      {panel === "notify" ? <NotifyPanel onClose={() => setPanel(null)} /> : null}
      {confirmLogout ? (
        <ConfirmSheet
          title="Выйти из аккаунта?"
          body="Переписка останется на этом устройстве, пока вы не очистите данные."
          confirmLabel={t.logout}
          danger
          onClose={() => setConfirmLogout(false)}
          onConfirm={() => {
            useTelechat.getState().logout();
            setConfirmLogout(false);
          }}
        />
      ) : null}
    </div>
  );
}

function Section({ children }: { children: ReactNode }) {
  return <div className="mb-3 overflow-hidden rounded-3xl bg-surface">{children}</div>;
}

function Row({
  icon: Icon,
  label,
  value,
  onClick,
}: {
  icon: typeof Bell;
  label: string;
  value?: string;
  onClick: () => void;
}) {
  return (
    <button type="button" onClick={onClick} className="tap flex min-h-12 w-full items-center gap-3 px-4 py-2.5 text-left">
      <span className="flex size-9 items-center justify-center rounded-xl bg-surface-2 text-accent">
        <Icon className="size-4" />
      </span>
      <span className="flex-1 font-medium">{label}</span>
      {value ? <span className="text-sm text-muted">{value}</span> : null}
      <ChevronRight className="size-4 text-subtle" />
    </button>
  );
}

function AppearancePanel({ onClose }: { onClose: () => void }) {
  const theme = useTelechat((s) => s.theme);
  const wallpaper = useTelechat((s) => s.wallpaper);
  const fontSize = useTelechat((s) => s.profile?.fontSize ?? "medium");
  return (
    <Overlay open onClose={onClose}>
      <h2 className="text-lg font-semibold">{t.appearance}</h2>
      <div className="mt-4 grid grid-cols-2 gap-2">
        {(["dark", "light"] as const).map((mode) => (
          <button
            key={mode}
            type="button"
            onClick={() => useTelechat.getState().setTheme(mode)}
            className={cn(
              "tap h-11 rounded-2xl text-sm font-medium",
              theme === mode ? "bg-accent text-accent-fg" : "bg-surface-2",
            )}
          >
            {mode === "dark" ? t.dark : t.light}
          </button>
        ))}
      </div>
      <p className="mt-5 text-xs font-medium text-muted">{t.wallpaper}</p>
      <div className="mt-2 grid grid-cols-5 gap-2">
        {WALLPAPERS.map((w) => (
          <button
            key={w.id}
            type="button"
            onClick={() => {
              useTelechat.setState({ wallpaper: w.id });
              useTelechat.getState().persist();
            }}
            className={cn("h-10 rounded-xl", `app-wallpaper-${w.id}`, wallpaper === w.id && "ring-2 ring-accent")}
            aria-label={w.label}
          />
        ))}
      </div>
      <p className="mt-5 text-xs font-medium text-muted">{t.fontSize}</p>
      <div className="mt-2 grid grid-cols-3 gap-2">
        {(["small", "medium", "large"] as const).map((size) => (
          <button
            key={size}
            type="button"
            onClick={() => useTelechat.getState().updateProfile({ fontSize: size })}
            className={cn(
              "tap h-11 rounded-2xl text-sm",
              fontSize === size ? "bg-accent text-accent-fg" : "bg-surface-2",
            )}
          >
            {t[size]}
          </button>
        ))}
      </div>
    </Overlay>
  );
}

function PinPanel({ onClose }: { onClose: () => void }) {
  const current = useTelechat((s) => s.profile?.pin);
  const [step, setStep] = useState<"create" | "confirm">("create");
  const [first, setFirst] = useState("");
  const [value, setValue] = useState("");
  const [error, setError] = useState<string | null>(null);

  const onDigit = (d: string) => {
    const next = (value + d).slice(0, PIN_LENGTH);
    setValue(next);
    setError(null);
    if (next.length < PIN_LENGTH) return;
    if (step === "create") {
      window.setTimeout(() => {
        setFirst(next);
        setValue("");
        setStep("confirm");
      }, 120);
      return;
    }
    if (next !== first) {
      setError(t.pinMismatch);
      window.setTimeout(() => {
        setValue("");
        setFirst("");
        setStep("create");
      }, 700);
      return;
    }
    if (!isValidPin(next)) {
      setError("Нужно ровно 6 цифр");
      return;
    }
    useTelechat.getState().setPin(next);
    onClose();
  };

  return (
    <Overlay open onClose={onClose}>
      <h2 className="text-lg font-semibold">{t.setPin}</h2>
      <p className="mt-2 text-sm text-muted">
        {step === "create" ? t.pinHint : t.pinRepeat}
      </p>
      <div className="mt-6">
        <PinDots value={value} length={PIN_LENGTH} />
      </div>
      {error ? <p className="mt-3 text-center text-sm text-danger">{error}</p> : null}
      <div className="mt-6">
        <NumericKeypad
          onDigit={onDigit}
          onBackspace={() => {
            setValue((v) => v.slice(0, -1));
            setError(null);
          }}
        />
      </div>
      {current ? (
        <button
          type="button"
          onClick={() => {
            useTelechat.getState().setPin(null);
            onClose();
          }}
          className="tap mt-3 h-11 w-full rounded-2xl text-sm text-danger"
        >
          Отключить
        </button>
      ) : null}
    </Overlay>
  );
}

function DevicesPanel({ onClose }: { onClose: () => void }) {
  const devices = useTelechat((s) => s.devices);
  return (
    <Overlay open onClose={onClose} className="max-h-[80vh] overflow-hidden">
      <h2 className="text-lg font-semibold">{t.devices}</h2>
      <div className="mt-3 space-y-2">
        {devices.map((d) => (
          <div key={d.id} className="flex items-center gap-3 rounded-2xl bg-surface-2 px-3 py-3">
            <Smartphone className="size-5 text-muted" />
            <div className="min-w-0 flex-1">
              <div className="font-medium">
                {d.name} {d.current ? <span className="text-xs text-accent">· {t.currentDevice}</span> : null}
              </div>
              <div className="text-xs text-muted">
                {d.location} · {formatChatTime(d.lastActive)}
              </div>
            </div>
            {!d.current ? (
              <button
                type="button"
                onClick={() => useTelechat.getState().terminateDevice(d.id)}
                className="text-xs font-medium text-danger"
              >
                {t.terminate}
              </button>
            ) : null}
          </div>
        ))}
      </div>
    </Overlay>
  );
}

function PrivacyPanel({ onClose }: { onClose: () => void }) {
  const profile = useTelechat((s) => s.profile);
  return (
    <Overlay open onClose={onClose}>
      <h2 className="text-lg font-semibold">{t.privacy}</h2>
      <p className="mt-4 text-xs font-medium text-muted">{t.lastSeenPrivacy}</p>
      <div className="mt-2 grid grid-cols-3 gap-2">
        {(["everyone", "contacts", "nobody"] as const).map((v) => (
          <button
            key={v}
            type="button"
            onClick={() => useTelechat.getState().updateProfile({ lastSeenPrivacy: v })}
            className={cn(
              "tap h-10 rounded-2xl text-xs font-medium",
              profile?.lastSeenPrivacy === v ? "bg-accent text-accent-fg" : "bg-surface-2",
            )}
          >
            {v === "everyone" ? t.everyone : v === "contacts" ? t.contactsOnly : t.nobody}
          </button>
        ))}
      </div>
      <button
        type="button"
        onClick={() =>
          useTelechat.getState().updateProfile({ readReceipts: !profile?.readReceipts })
        }
        className="tap mt-4 flex h-12 w-full items-center justify-between rounded-2xl bg-surface-2 px-4 text-sm"
      >
        {t.readReceipts}
        <span className={cn("size-5 rounded-full", profile?.readReceipts ? "bg-accent" : "bg-border-strong")} />
      </button>
    </Overlay>
  );
}

function NotifyPanel({ onClose }: { onClose: () => void }) {
  const profile = useTelechat((s) => s.profile);
  return (
    <Overlay open onClose={onClose}>
      <h2 className="text-lg font-semibold">{t.notifications}</h2>
      <button
        type="button"
        onClick={() =>
          useTelechat.getState().updateProfile({ notificationSound: !profile?.notificationSound })
        }
        className="tap mt-4 flex h-12 w-full items-center justify-between rounded-2xl bg-surface-2 px-4 text-sm"
      >
        {t.sound}
        <span className={cn("size-5 rounded-full", profile?.notificationSound ? "bg-accent" : "bg-border-strong")} />
      </button>
    </Overlay>
  );
}
