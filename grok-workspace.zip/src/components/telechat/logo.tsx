import { cn } from "@/lib/utils";

export function TelechatMark({ className }: { className?: string }) {
  return (
    <img
      src="/logo.jpg"
      alt="TeleChat"
      className={cn("size-10 rounded-[22%] object-cover ring-1 ring-border", className)}
    />
  );
}

export function TelechatWordmark({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <TelechatMark />
      {compact ? null : (
        <span className="text-[17px] font-semibold tracking-tight text-fg">TeleChat</span>
      )}
    </div>
  );
}
