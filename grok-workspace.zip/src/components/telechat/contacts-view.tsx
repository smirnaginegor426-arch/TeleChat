import { Search, UserPlus } from "lucide-react";
import { useShallow } from "zustand/react/shallow";
import { UserAvatar } from "@/components/telechat/user-avatar";
import { t } from "@/lib/telechat/constants";
import { formatLastSeen, withAt } from "@/lib/telechat/format";
import { selectContacts, useTelechat } from "@/store/telechat-store";

export function ContactsView() {
  const contacts = useTelechat(useShallow(selectContacts));
  const query = useTelechat((s) => s.ui.contactQuery);

  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="px-4 pt-[max(0.9rem,env(safe-area-inset-top))] pb-3">
        <h1 className="text-[28px] font-semibold tracking-tight">{t.contacts}</h1>
        <label className="mt-3 flex h-11 items-center gap-2 rounded-2xl bg-surface px-3">
          <Search className="size-4 text-muted" />
          <input
            value={query}
            onChange={(e) => useTelechat.getState().setContactQuery(e.target.value)}
            placeholder={t.searchContacts}
            className="h-full w-full bg-transparent text-[15px] outline-none placeholder:text-subtle"
          />
        </label>
      </header>
      <div className="min-h-0 flex-1 overflow-y-auto px-2 pb-4">
        {contacts.length === 0 ? (
          <div className="flex h-[48vh] flex-col items-center justify-center px-8 text-center">
            <div className="flex size-16 items-center justify-center rounded-3xl bg-surface">
              <UserPlus className="size-6 text-muted" />
            </div>
            <p className="mt-4 font-semibold">{t.emptyContacts}</p>
            <p className="mt-1 text-sm text-muted">Попробуйте @username из адресной книги.</p>
          </div>
        ) : (
          contacts.map((contact) => (
            <button
              key={contact.id}
              type="button"
              onClick={() => useTelechat.getState().createDirectChat(contact.id)}
              className="tap flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left hover:bg-surface"
            >
              <UserAvatar avatar={contact.avatar} online={contact.online} />
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-2">
                  <span className="truncate font-semibold">{contact.displayName}</span>
                  {contact.isOfficial ? (
                    <span className="rounded-full bg-accent-soft px-1.5 py-0.5 text-[10px] font-semibold text-accent">
                      официальный
                    </span>
                  ) : null}
                </span>
                <span className="block truncate text-sm text-muted">
                  {contact.online ? t.online : formatLastSeen(contact.lastSeen)} · {withAt(contact.username)}
                </span>
              </span>
            </button>
          ))
        )}
      </div>
    </div>
  );
}
