import {
  Archive,
  ArrowLeft,
  BellOff,
  Copy,
  Forward,
  Info,
  MoreHorizontal,
  Pin,
  Trash2,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useShallow } from "zustand/react/shallow";
import { Composer } from "@/components/telechat/composer";
import { MessageBubble, ReactionPicker } from "@/components/telechat/message-bubble";
import { ConfirmSheet } from "@/components/telechat/sheet";
import { UserAvatar } from "@/components/telechat/user-avatar";
import { t } from "@/lib/telechat/constants";
import { formatLastSeen, formatMembers } from "@/lib/telechat/format";
import { ME_ID } from "@/lib/telechat/ids";
import type { Message, ReactionId } from "@/lib/telechat/types";
import { chatPeer, useTelechat } from "@/store/telechat-store";
import { cn } from "@/lib/utils";

export function ChatView({ chatId, onBack }: { chatId: string; onBack: () => void }) {
  const chat = useTelechat((s) => s.chats.find((c) => c.id === chatId));
  const messages = useTelechat(
    useShallow((s) => (s.messages[chatId] ?? []).filter((m) => !m.deletedForMe)),
  );
  const wallpaper = useTelechat((s) => s.wallpaper);
  const peer = useTelechat((s) => (chat ? chatPeer(s, chat) : undefined));
  const scroller = useRef<HTMLDivElement>(null);
  const [menu, setMenu] = useState<{ message: Message; x: number; y: number } | null>(null);
  const [headerMenu, setHeaderMenu] = useState(false);
  const [confirm, setConfirm] = useState<null | "me" | "all" | "chat-me" | "chat-all">(null);

  useEffect(() => {
    const el = scroller.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages.length, chatId]);

  if (!chat) {
    return (
      <div className="flex h-full items-center justify-center text-sm text-muted">Чат не найден</div>
    );
  }

  const typing = useTelechat((s) =>
    s.contacts.some((c) => chat.participantIds.includes(c.id) && c.typing),
  );
  const subtitle = chat.type === "group"
    ? formatMembers(chat.participantIds.length)
    : typing
      ? "печатает…"
      : peer && "online" in peer && peer.online
        ? t.online
        : peer && "lastSeen" in peer
          ? formatLastSeen(peer.lastSeen)
          : "";

  return (
    <div className={cn("relative flex h-full min-h-0 flex-col", `app-wallpaper-${wallpaper}`)}>
      <header className="flex items-center gap-1 border-b border-border bg-bg-elevated/90 px-1 py-1.5 pt-[max(0.4rem,env(safe-area-inset-top))] backdrop-blur-md">
        <button
          type="button"
          onClick={onBack}
          className="tap flex size-11 items-center justify-center rounded-2xl md:hidden"
          aria-label="Назад"
        >
          <ArrowLeft className="size-5" />
        </button>
        <button
          type="button"
          onClick={() => useTelechat.getState().setChatInfoOpen(true)}
          className="flex min-w-0 flex-1 items-center gap-3 rounded-2xl px-1 py-1 text-left"
        >
          <UserAvatar avatar={chat.avatar} size="sm" online={peer && "online" in peer ? peer.online : false} />
          <span className="min-w-0">
            <span className="block truncate font-semibold tracking-tight">{chat.title}</span>
            <span className="block truncate text-xs text-muted">{subtitle}</span>
          </span>
        </button>
        <button
          type="button"
          onClick={() => setHeaderMenu((v) => !v)}
          className="tap flex size-11 items-center justify-center rounded-2xl"
          aria-label="Ещё"
        >
          <MoreHorizontal className="size-5" />
        </button>
      </header>

      {headerMenu ? (
        <div className="absolute top-[4.2rem] right-3 z-20 w-56 overflow-hidden rounded-2xl border border-border bg-surface shadow-[var(--shadow-float)]">
          <MenuItem icon={Pin} label={chat.pinned ? t.unpin : t.pin} onClick={() => { useTelechat.getState().pinChat(chatId, !chat.pinned); setHeaderMenu(false); }} />
          <MenuItem icon={BellOff} label={chat.muted ? t.unmute : t.mute} onClick={() => { useTelechat.getState().muteChat(chatId, !chat.muted); setHeaderMenu(false); }} />
          <MenuItem icon={Archive} label={chat.archived ? "Вернуть из архива" : t.archive} onClick={() => { useTelechat.getState().archiveChat(chatId, !chat.archived); setHeaderMenu(false); }} />
          <MenuItem icon={Info} label="О чате" onClick={() => { useTelechat.getState().setChatInfoOpen(true); setHeaderMenu(false); }} />
          <MenuItem icon={Trash2} label={t.deleteForMe} danger onClick={() => { setConfirm("chat-me"); setHeaderMenu(false); }} />
          <MenuItem icon={Trash2} label={t.deleteForAll} danger onClick={() => { setConfirm("chat-all"); setHeaderMenu(false); }} />
        </div>
      ) : null}

      <div ref={scroller} className="min-h-0 flex-1 space-y-1.5 overflow-y-auto px-3 py-3">
        {messages.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center text-center text-sm text-muted">
            {t.emptyMessages}
          </div>
        ) : (
          messages.map((message, i) => (
            <MessageBubble
              key={message.id}
              message={message}
              grouped={
                i > 0 &&
                messages[i - 1].senderId === message.senderId &&
                message.createdAt - messages[i - 1].createdAt < 120000
              }
              onLongPress={(m, x, y) => setMenu({ message: m, x, y })}
            />
          ))
        )}
      </div>

      <Composer chatId={chatId} />

      {menu ? (
        <div
          className="fixed inset-0 z-40"
          onClick={() => setMenu(null)}
          onContextMenu={(e) => e.preventDefault()}
        >
          <div
            className="absolute w-[220px]"
            style={{
              left: Math.min(menu.x, window.innerWidth - 230),
              top: Math.min(menu.y, window.innerHeight - 280),
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <ReactionPicker
              onPick={(id: ReactionId) => {
                useTelechat.getState().toggleReaction(chatId, menu.message.id, id);
                setMenu(null);
              }}
            />
            <div className="mt-2 overflow-hidden rounded-2xl border border-border bg-surface shadow-[var(--shadow-float)]">
              <MenuItem icon={Copy} label={t.copy} onClick={() => { void useTelechat.getState().copyMessage(menu.message.id); setMenu(null); }} />
              <MenuItem icon={Forward} label={t.forward} onClick={() => { useTelechat.getState().setForwardMessage(menu.message.id); setMenu(null); }} />
              <MenuItem
                icon={Trash2}
                label={t.deleteForMe}
                danger
                onClick={() => {
                  setConfirm("me");
                }}
              />
              {menu.message.senderId === ME_ID ? (
                <MenuItem
                  icon={Trash2}
                  label={t.deleteForAll}
                  danger
                  onClick={() => setConfirm("all")}
                />
              ) : null}
            </div>
          </div>
        </div>
      ) : null}

      {confirm === "me" || confirm === "all" ? (
        <ConfirmSheet
          title={confirm === "all" ? t.deleteForAll : t.deleteForMe}
          body="Сообщение исчезнет из этой переписки."
          confirmLabel={t.delete}
          danger
          onClose={() => { setConfirm(null); setMenu(null); }}
          onConfirm={() => {
            if (menu) useTelechat.getState().deleteMessage(chatId, menu.message.id, confirm === "all");
            setConfirm(null);
            setMenu(null);
          }}
        />
      ) : null}
      {confirm === "chat-me" || confirm === "chat-all" ? (
        <ConfirmSheet
          title={confirm === "chat-all" ? "Удалить чат у всех" : "Удалить чат у себя"}
          body="История переписки будет скрыта."
          confirmLabel={t.delete}
          danger
          onClose={() => setConfirm(null)}
          onConfirm={() => {
            useTelechat.getState().deleteChat(chatId, confirm === "chat-all");
            setConfirm(null);
            onBack();
          }}
        />
      ) : null}
    </div>
  );
}

function MenuItem({
  icon: Icon,
  label,
  onClick,
  danger,
}: {
  icon: typeof Copy;
  label: string;
  onClick: () => void;
  danger?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex h-11 w-full items-center gap-3 px-3 text-sm",
        danger ? "text-danger" : "text-fg",
      )}
    >
      <Icon className="size-4" />
      {label}
    </button>
  );
}
