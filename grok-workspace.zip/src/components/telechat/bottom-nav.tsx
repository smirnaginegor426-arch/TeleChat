import { MessageCircle, Settings, UserRound, Users } from "lucide-react";
import { t } from "@/lib/telechat/constants";
import type { TabId } from "@/lib/telechat/types";
import { useTelechat } from "@/store/telechat-store";
import { cn } from "@/lib/utils";

const TABS: Array<{ id: TabId; label: string; icon: typeof MessageCircle }> = [
  { id: "chats", label: t.chats, icon: MessageCircle },
  { id: "contacts", label: t.contacts, icon: Users },
  { id: "profile", label: t.you, icon: UserRound },
  { id: "settings", label: t.settings, icon: Settings },
];

export function BottomNav() {
  const tab = useTelechat((s) => s.ui.tab);
  const setTab = useTelechat((s) => s.setTab);
  const unread = useTelechat((s) =>
    s.chats.reduce((sum, c) => sum + (c.archived || c.deletedForMe ? 0 : c.unread), 0),
  );

  return (
    <nav className="flex justify-center bg-transparent px-4 pt-2 pb-[max(0.7rem,env(safe-area-inset-bottom))]">
      <div className="flex items-center gap-0.5 rounded-full bg-[#14181e] p-1.5 shadow-[0_16px_40px_rgb(0_0_0_/_45%)] ring-1 ring-white/8">
        {TABS.map((item) => {
          const active = tab === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                setTab(item.id);
                useTelechat.getState().openChat(null);
              }}
              className={cn(
                "relative flex min-w-[72px] flex-col items-center justify-center gap-0.5 rounded-full px-3 py-2 text-[11px] font-medium transition-[background-color,box-shadow,color,transform] duration-250 ease-[cubic-bezier(0.22,1,0.36,1)]",
                active
                  ? "bg-white/14 text-white shadow-[0_0_28px_rgb(255_255_255_/_18%)]"
                  : "text-white/55 hover:text-white/80",
              )}
            >
              <span className="relative">
                <Icon
                  className="size-5 transition-transform duration-250"
                  strokeWidth={active ? 2.4 : 1.7}
                  fill={active ? "currentColor" : "none"}
                />
                {item.id === "chats" && unread > 0 ? (
                  <span className="absolute -top-1.5 -right-2.5 min-w-4 rounded-full bg-white px-1 text-[9px] font-semibold text-black">
                    {unread > 99 ? "99+" : unread}
                  </span>
                ) : null}
              </span>
              {item.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
